from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.db.models import Avg, Sum, F, ExpressionWrapper, DecimalField
from django.contrib import messages
from club_dashboard.models import SalonAppointment,Notification
from django.core.paginator import Paginator
from receptionist_dashboard.models import SalonBooking,BookingService
from django.db import models , transaction
from datetime import datetime, timedelta
import datetime
from django.forms import formset_factory
from django.contrib.auth.decorators import login_required
from receptionist_dashboard.forms import SalonBookingForm ,ServiceSelectionForm
from django.http import JsonResponse
from .models import ProductsModel , CartItem,ServiceCartItem,OrderItem,Order
from accounts.models import UserProfile ,User,StudentProfile
from django import forms
import base64
from decimal import Decimal
from django.utils import translation
from django.utils.translation import get_language
from django.utils.formats import localize
from decimal import Decimal
import logging
import datetime
from django.utils import timezone





# Import necessary models
from .models import (
    Blog, ServicesModel, ServicesClassificationModel,
    ProductsModel, ProductsClassificationModel, ServiceOrderModel
)
from club_dashboard.models import Review  # ✅ Import Review from club_dashboard
from accounts.models import ClubsModel, CoachProfile, StudentProfile
from coach_dashboard.models import StudentAppointmentPresenceModel, CoachAppointmentsModel

# Import necessary forms
from .forms import ReviewForm


# from django.contrib import messages

import datetime
# Create your views here.

def get_user_club(user):
    user_profile = user.userprofile
    club = None
    if user_profile.account_type == '3':  # Student
        club = user_profile.student_profile.club if hasattr(user_profile, 'student_profile') else None
    elif user_profile.account_type == '4':  # Coach
        club = user_profile.Coach_profile.club if hasattr(user_profile, 'Coach_profile') else None
    elif user_profile.account_type == '2':  # Director
        club = user_profile.director_profile.club if hasattr(user_profile, 'director_profile') else None
    elif user_profile.account_type == '5':  # Receptionist
        club = user_profile.receptionist_profile.club if hasattr(user_profile, 'receptionist_profile') else None
    return club


def index(request):
    context = {}
    user = request.user
    print(f"User authenticated: {user.is_authenticated}")

    try:
        userprofile = UserProfile.objects.get(user=user)
        student = userprofile.student_profile
        print(f"User: {user}, Profile: {getattr(user, 'userprofile', None)}")
        print(f"Student Profile: {getattr(userprofile, 'student_profile', None) if 'userprofile' in locals() else None}")
        print(f"Club: {getattr(student, 'club', None) if 'student' in locals() else None}")

        if not student:
            messages.error(request, "No student profile found for this user.")
            return redirect('signin')

        club = student.club
        student_identifier = student.full_name

        if not club:
            messages.error(request, "No club associated with this student.")
            return redirect('signin')  # or an appropriate error page

        coaches = CoachProfile.objects.filter(club=club)
        students = StudentProfile.objects.filter(club=club)

        # Check subscription status
        subscription_status = student.get_subscription_status()

        # Activate a 30-day subscription when a student signs up (if they don't have one)
        if not student.subscription_start_date:
            student.subscription_start_date = timezone.now()
            student.subscription_end_date = timezone.now() + datetime.timedelta(days=30)
            student.has_subscription = True
            student.save()

        # Fetch all services and products related to the club
        services = ServicesModel.objects.filter(club=club)
        products = ProductsModel.objects.filter(club=club)

        # Get active service orders for this student - similar to salon_appointments view
        active_service_orders = ServiceOrderModel.objects.filter(
            student=request.user,
            service__isnull=False
        ).select_related('service')

        # Filter to only include active subscriptions
        active_service_ids = []
        now = timezone.now()

        for order in active_service_orders:
            # Check if service subscription is still active (end_datetime is in the future)
            if order.end_datetime >= now:
                active_service_ids.append(order.service.id)

        print(f"Found {len(active_service_ids)} active service subscriptions for student")

        # Show appointments only if the student has an active subscription
        if subscription_status == "active" or subscription_status == "expiring_soon":
            # Fetch appointments the same way as in salon_appointments
            days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']

            # Collect all appointments across all days
            all_appointments = []

            for day in days:
                try:
                    # Filter appointments that match both:
                    # 1. The student's club
                    # 2. Services that the student has active subscriptions for
                    day_appointments = SalonAppointment.objects.filter(
                        day=day,
                        club=club,
                        is_paid=True,
                        booking__services__service_id__in=active_service_ids  # Filter by active service subscriptions
                    ).order_by('start_time').distinct()

                    all_appointments.extend(day_appointments)
                except Exception as e:
                    print(f"ERROR processing day {day}: {str(e)}")

            print(f"Found {len(all_appointments)} confirmed appointments for student {student_identifier}")
            appointments = all_appointments
        else:
            appointments = []  # Empty list if subscription is expired


        three_days_from_now = timezone.now() + datetime.timedelta(days=3)
        lang = translation.get_language()
        context['LANGUAGE_CODE'] = lang
        service_orders = ServiceOrderModel.objects.filter(student=user).select_related('service').order_by('-end_datetime')
        context['service_orders'] = service_orders
        context['manual_status'] = student.manual_status
        context['today'] = timezone.now()  # Add today's date for the template

        return render(request, 'student/index.html', {
            'coaches': coaches,
            'students': students,
            'club': club,
            'services': services,
            'products': products,
            'appointments': appointments,
            'subscription_status': subscription_status,
            'subscription_end_date': student.subscription_end_date,
            'service_orders': service_orders,
            'manual_status': student.manual_status,
            'today': timezone.now(),
            'three_days_from_now': three_days_from_now,
        })

    except UserProfile.DoesNotExist as e:
        print(f"UserProfile.DoesNotExist: {str(e)}")
        messages.error(request, "User profile not found.")
        return redirect('signin')  # or an appropriate error page
    except Exception as e:
        print(f"Unexpected exception: {str(e)}")
        messages.error(request, f"An unexpected error occurred: {str(e)}")
        return redirect('signin')  # or an appropriate error page




def viewProducts(request):
    context = {}
    user = request.user
    club = user.userprofile.student_profile.club
    products = ProductsModel.objects.filter(club=club)
    # classifications = ClassificationModel.objects.all()  # Get all available classifications

    total_products = products.count()
    total_value = 0
    low_stock_count = 0
    out_of_stock_count = 0
    low_stock_threshold = 10

    for product in products:
        if hasattr(product, 'stock'):
            product_value = product.price * product.stock
            total_value += product_value

            if 0 < product.stock <= low_stock_threshold:
                low_stock_count += 1

            if product.stock == 0:
                out_of_stock_count += 1

    paginator = Paginator(products, 6)
    page_number = request.GET.get('page', 1)
    paginated_products = paginator.get_page(page_number)

    context = {
        'products': paginated_products,
        # 'classifications': classifications,
        'total_products': total_products,
        'total_value': total_value,
        'low_stock_count': low_stock_count,
        'out_of_stock_count': out_of_stock_count,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/products/viewProducts.html', context)

def extract_features(description):
    """Helper function to extract product features from description"""
    if description:
        return [
            "مصنوعة من مواد فائقة الجودة",
            "تصميم عصري وأنيق",
            "سهولة الاستخدام",
            "ضمان لمدة سنة"
        ]
    return []

def viewProductsSpecific(request, id):
    context = {}
    user = request.user
    club = user.userprofile.student_profile.club

    product = ProductsModel.objects.get(id=id)

    product.features = extract_features(product.desc)

    from datetime import timedelta
    from django.utils import timezone
    product.is_new = product.created_at >= timezone.now() - timedelta(days=7) if hasattr(product, 'created_at') else False

    related_products = ProductsModel.objects.filter(club=club).exclude(id=id)[:3]

    context = {
        'product': product,
        'products': related_products,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/products/viewSpecific.html', context)



def viewServices(request):
    context = {}
    user = request.user
    club = user.userprofile.student_profile.club
    services = ServicesModel.objects.filter(club=club)
    classifications = ProductsClassificationModel.objects.filter(club=club)

    if services:
        avg_price = sum(service.discounted_price or service.price for service in services) / len(services)
        avg_price = round(avg_price, 1)

        avg_duration = sum(service.duration for service in services) / len(services)
        avg_duration_hours = int(avg_duration // 60)
        avg_duration_minutes = int(avg_duration % 60)
    else:
        avg_price = 0
        avg_duration_hours = 0
        avg_duration_minutes = 0

    context = {
        'services': services,
        'classifications': classifications,
        'avg_price': avg_price,
        'avg_duration_hours': avg_duration_hours,
        'avg_duration_minutes': avg_duration_minutes,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/services/viewServices.html', context)

def viewServicesSpecific(request, id):
    context = {}
    user = request.user
    club = user.userprofile.student_profile.club
    service = ServicesModel.objects.get(id=id)
    services = ServicesModel.objects.filter(club=club)
    order = ServiceOrderModel.objects.filter(service=service, student=user).order_by('-id').first()
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/services/viewSpecific.html', {'service':service, 'services':services, 'order':order})


def viewArticles(request):
    user = request.user
    club = user.userprofile.student_profile.club
    arts = Blog.objects.filter(club=club)
    featured_article = arts.order_by('-creation_date').first()

    context = {
        'arts': arts,
        'featured_article': featured_article
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/blog/viewArticless.html', context)

def viewArticle(request,id):
    user = request.user
    club = user.userprofile.student_profile.club

    try:
        article = Blog.objects.get(id=id, club=club)

        related_articles = Blog.objects.filter(club=club).exclude(id=id)[:3]

        context = {
            'article': article,
            'related_articles': related_articles
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'student/blog/viewArticle.html', context)

    except Blog.DoesNotExist:
        return redirect('viewArticles')


def OrderService(request, service_id):
    student = request.user
    service = ServicesModel.objects.get(id=service_id)
    orders = ServiceOrderModel.objects.filter(service=service, student=student).order_by('-id')
    if orders.exists():
        if orders.first().has_subscription():
            return redirect('viewServicesSpecific', service_id)
    end_datetime = datetime.timedelta(days=30) + timezone.now()
    order = ServiceOrderModel.objects.create(service=service, student=student, price=service.price, is_complited=True, end_datetime=end_datetime, creation_date=timezone.now())
    order.save()
    return redirect('studentIndex')

def add_review(request):
    context = {}
    """Allows a student to review any coach in their club."""
    user = request.user

    # ✅ Ensure user has a valid StudentProfile
    student_profile = getattr(user.userprofile, 'student_profile', None)
    if not student_profile:
        messages.error(request, "❌ لم يتم العثور على ملف الطالب الخاص بك.")
        return redirect('studentIndex')

    club = student_profile.club
    if not club:
        messages.error(request, "❌ أنت غير مسجل في أي نادٍ.")
        return redirect('studentIndex')

    # ✅ Get all coaches in the club
    coaches = CoachProfile.objects.filter(club=club)

    if request.method == 'POST':
        selected_coach_id = request.POST.get('coach_id')

        if not selected_coach_id:
            messages.error(request, "❌ يرجى اختيار مدرب لإضافة تقييم.")
            return redirect('add_review')

        # ✅ Check if the coach exists
        coach_profile = get_object_or_404(CoachProfile, id=selected_coach_id)

        # ✅ Check if the student already reviewed this coach
        existing_review = Review.objects.filter(student=student_profile, coach=coach_profile).first()

        # ✅ Use form with instance for updating existing review
        form = ReviewForm(request.POST, instance=existing_review)

        if form.is_valid():
            review = form.save(commit=False)
            review.student = student_profile
            review.coach = coach_profile
            review.save()

            messages.success(request, "✅ تم إرسال التقييم بنجاح!")
            return redirect('view_reviews')
        else:
            messages.error(request, f"❌ حدث خطأ أثناء إرسال التقييم: {form.errors}")
    else:
        form = ReviewForm()
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/reviews/add_review.html', {
        'form': form,
        'coaches': coaches  # ✅ Correctly passing only relevant coaches
    })
    
def view_reviews(request):
    context = {}
    """Displays the reviews written by the logged-in student."""
    user = request.user

    # ✅ Ensure user has a valid UserProfile and StudentProfile
    try:
        student_profile = user.userprofile.student_profile
    except AttributeError:
        messages.error(request, "لم يتم العثور على ملف الطالب الخاص بك.")
        return redirect('studentIndex')

    # ✅ Fetch only the reviews this student wrote
    student_reviews = Review.objects.filter(student=student_profile).select_related('coach').order_by('-created_at')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/reviews/view_reviews.html', {
        'student_reviews': student_reviews,
    })
      
def edit_review(request, review_id):
    context = {}
    """Allows a student to edit their existing review."""
    user = request.user
    review = get_object_or_404(Review, id=review_id, student=user.userprofile.student_profile)

    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            messages.success(request, "تم تعديل التقييم بنجاح!")
            return redirect('view_reviews')
    else:
        form = ReviewForm(instance=review)
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/reviews/edit_review.html', {'form': form, 'review': review})




@login_required
def salon_appointments(request):
    context = {}
    days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']

    time_slots = []
    for hour in range(1, 13):
        current_time = datetime.datetime.strptime(f'{hour:02d}:00:00 AM', '%I:%M:%S %p').time()
        time_slots.append(current_time)
    for hour in range(1, 13):
        current_time = datetime.datetime.strptime(f'{hour:02d}:00:00 PM', '%I:%M:%S %p').time()
        time_slots.append(current_time)

    schedule = {}

    try:
        # Get user profile and student profile
        try:
            userprofile = UserProfile.objects.get(user=request.user)
            student = userprofile.student_profile

            if not student:
                messages.error(request, "No student profile found for this user.")
                return render(request, 'student/blog/viewArticles.html', {
                    'schedule': {},
                    'days': days,
                    'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots]
                })

        except UserProfile.DoesNotExist:
            messages.error(request, "User profile not found.")
            return render(request, 'student/blog/viewArticles.html', {
                'schedule': {},
                'days': days,
                'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots]
            })

        club = get_user_club(request.user)

        if not club:
            messages.error(request, "No club assigned to your profile. Please contact an administrator.")
            return render(request, 'student/blog/viewArticles.html', {
                'schedule': {},
                'days': days,
                'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots]
            })

        # Get active service orders for this student
        # Similar to how it's done in the index view
        active_service_orders = ServiceOrderModel.objects.filter(
            student=request.user,
            service__isnull=False
        ).select_related('service')

        # Filter to only include active subscriptions
        active_service_ids = []
        now = timezone.now()

        for order in active_service_orders:
            # Check if service subscription is still active (end_datetime is in the future)
            if order.end_datetime >= now:
                active_service_ids.append(order.service.id)

        print(f"Found {len(active_service_ids)} active service subscriptions for student")

        for day in days:
            schedule[day] = []

            try:
                # Filter appointments that match both:
                # 1. The student's club
                # 2. Services that the student has active subscriptions for
                appointments = SalonAppointment.objects.filter(
                    day=day,
                    club=club,
                    is_paid=True,
                    booking__services__service_id__in=active_service_ids  # Filter by active service subscriptions
                ).order_by('start_time').distinct()

                for slot in time_slots:
                    slot_end = (datetime.datetime.combine(datetime.datetime.today(), slot) + timedelta(hours=1)).time()

                    try:
                        slot_appointments = appointments.filter(
                            start_time__gte=slot,
                            start_time__lt=slot_end
                        )

                        booking_count = slot_appointments.count()
                        slot_info = {
                            'time': slot.strftime('%I:%M %p'),
                            'booking_count': booking_count,
                            'has_bookings': booking_count > 0,
                            'appointments': []
                        }

                        # Process each appointment with proper error handling
                        for appt in slot_appointments:
                            print(f"Processing appointment ID: {appt.id}")
                            try:
                                if hasattr(appt, 'booking'):
                                    slot_info['appointments'].append({
                                        'id': appt.id,
                                        'start': appt.start_time.strftime('%I:%M %p'),
                                        'end': appt.end_time.strftime('%I:%M %p') if appt.end_time else "N/A"
                                    })
                                else:
                                    print(f"Appointment {appt.id} has no booking")
                            except Exception as e:
                                print(f"ERROR processing appointment {appt.id}: {str(e)}")
                                continue

                        schedule[day].append(slot_info)

                    except Exception as e:
                        print(f"ERROR processing time slot {slot}: {str(e)}")
                        # Add a placeholder for this time slot
                        schedule[day].append({
                            'time': slot.strftime('%I:%M %p'),
                            'booking_count': 0,
                            'has_bookings': False,
                            'appointments': []
                        })

            except Exception as e:
                print(f"ERROR processing day {day}: {str(e)}")
                # Add empty data for this day
                schedule[day] = [{
                    'time': slot.strftime('%I:%M %p'),
                    'booking_count': 0,
                    'has_bookings': False,
                    'appointments': []
                } for slot in time_slots]

    except Exception as e:
        print(f"CRITICAL ERROR in salon_appointments: {str(e)}")
        import traceback
        print(traceback.format_exc())
        messages.error(request, f"An error occurred while loading appointments. Please try again later.")

    print("Rendering template...")
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/blog/viewArticles.html', {
        'schedule': schedule,
        'days': days,
        'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots],
        'club': club if 'club' in locals() else None,
    })


@login_required
def slot_appointments(request, day, time):
    try:
        # Get user profile and student profile first
        try:
            userprofile = UserProfile.objects.get(user=request.user)
            student = userprofile.student_profile

            if not student:
                messages.error(request, "No student profile found for this user.")
                return redirect('studentViewArticles')

        except UserProfile.DoesNotExist:
            messages.error(request, "User profile not found.")
            return redirect('studentViewArticles')

        club = get_user_club(request.user)

        if not club:
            print("No club assigned to user profile")
            messages.error(request, "No club assigned to your profile. Please contact an administrator.")
            return redirect('index')

        # Get active service orders for this student
        active_service_orders = ServiceOrderModel.objects.filter(
            student=request.user,
            service__isnull=False
        ).select_related('service')

        # Filter to only include active subscriptions
        active_service_ids = []
        now = timezone.now()

        for order in active_service_orders:
            # Check if service subscription is still active (end_datetime is in the future)
            if order.end_datetime >= now:
                active_service_ids.append(order.service.id)

        print(f"Found {len(active_service_ids)} active service subscriptions for student")

        try:
            if ':' in time:
                print("Parsing time string...")
                hour_str, minute_str = time.split(':')
                hour = int(hour_str)
                minute = int(minute_str.split(' ')[0])
                period = time.split(' ')[1]
                print(f"Parsed time: Hour={hour}, Minute={minute}, Period={period}")

                if period == 'PM' and hour < 12:
                    hour += 12
                elif period == 'AM' and hour == 12:
                    hour = 0

                time_obj = datetime.datetime.strptime(f'{hour:02d}:{minute:02d}:00', '%H:%M:%S').time()
                slot_end = (datetime.datetime.combine(datetime.datetime.today(), time_obj) + timedelta(hours=1)).time()
                print(f"Calculated time_obj: {time_obj}, slot_end: {slot_end}")

                print("Querying appointments...")
                # Get appointments with confirmed payments AND for services with active subscriptions
                appointments = SalonAppointment.objects.filter(
                    day=day,
                    club=club,
                    is_paid=True,
                    start_time__gte=time_obj,
                    start_time__lt=slot_end,
                    booking__services__service_id__in=active_service_ids  # Filter by active service subscriptions
                ).select_related('booking').distinct()

                print(f"Found {appointments.count()} appointments with active subscriptions")

                appointment_details = []
                for appt in appointments:
                    print(f"Processing appointment ID: {appt.id}")
                    try:
                        if hasattr(appt, 'booking') and appt.booking:
                            print(f"Appointment has booking")
                            booking = appt.booking

                            # Safe access to services
                            try:
                                print("Getting booking services...")
                                # Only include services that the student has active subscriptions for
                                services = BookingService.objects.filter(
                                    booking=booking,
                                    service_id__in=active_service_ids
                                ).select_related('service')

                                print(f"Found {services.count()} active services")
                                service_names = ", ".join([s.service.title for s in services if hasattr(s, 'service')])
                                total_price = sum(getattr(s.service, 'price', 0) for s in services if hasattr(s, 'service'))
                            except Exception as e:
                                print(f"ERROR getting services: {str(e)}")
                                service_names = "N/A"
                                total_price = 0

                            appointment_details.append({
                                'id': appt.id,
                                'services': service_names,
                                'employee': getattr(booking, 'employee', "N/A"),
                                'start_time': appt.start_time.strftime('%I:%M %p'),
                                'end_time': appt.end_time.strftime('%I:%M %p') if appt.end_time else "N/A",
                                'total_price': total_price
                            })
                        else:
                            print(f"Appointment {appt.id} has no booking")
                    except Exception as e:
                        print(f"ERROR processing appointment detail {appt.id}: {str(e)}")
                        import traceback
                        print(traceback.format_exc())
                        continue

                print("Rendering template with appointment details")
                context = {
                    'day': day,
                    'time_slot': time,
                    'appointments': appointment_details
                }
                context['LANGUAGE_CODE'] = translation.get_language()
                return render(request, 'student/blog/slot_appointments.html', context)

        except Exception as e:
            print(f"ERROR in slot_appointments: {str(e)}")
            import traceback
            print(traceback.format_exc())
            messages.error(request, f"Error retrieving appointments: {str(e)}")
            return redirect('studentViewArticles')

    except Exception as e:
        print(f"CRITICAL ERROR in slot_appointments: {str(e)}")
        import traceback
        print(traceback.format_exc())
        messages.error(request, "An unexpected error occurred. Please try again later.")
        return redirect('index')




@login_required
def get_service_info(request, service_id):
    """
    Returns JSON with service information including duration and associated coaches
    """
    try:
        service = ServicesModel.objects.get(id=service_id)
        coaches = service.coaches.all()

        coach_data = [
            {
                'id': coach.id,
                'name': coach.full_name
            } for coach in coaches
        ]

        return JsonResponse({
            'duration': service.duration,
            'coaches': coach_data
        })
    except ServicesModel.DoesNotExist:
        return JsonResponse({'error': 'Service not found'}, status=404)

@login_required
def get_service_duration(request, service_id):
    try:
        service = ServicesModel.objects.get(id=service_id)
        return JsonResponse({'duration': service.duration})
    except ServicesModel.DoesNotExist:
        return JsonResponse({'duration': 0})



@login_required
def appointment_details(request, appointment_id):
    club = get_user_club(request.user)

    if not club:
        messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
        return redirect('index')

    appointment = get_object_or_404(SalonAppointment, id=appointment_id)
    if appointment.club != club:
        messages.error(request, "ليس لديك صلاحية لعرض هذا الموعد.")
        return redirect('receptionist_salon_appointments')

    try:
        booking = appointment.booking
        # Explicitly fetch booking services
        booking_services = BookingService.objects.filter(booking=booking).select_related('service')

        if not booking_services.exists():
            messages.warning(request, "لا توجد خدمات مرتبطة بهذا الحجز")

        # For debugging
        print(f"Found {booking_services.count()} services for booking {booking.id}")

        context = {
            'appointment': appointment,
            'booking': booking,
            'employee': booking.employee,
            'booking_services': booking_services,  # Change the variable name to be more explicit
            'total_price': sum(bs.service.price for bs in booking_services),
            'total_duration': sum(bs.service.duration for bs in booking_services),
            'club':club
        }
    except Exception as e:
        messages.error(request, f"لم يتم العثور على معلومات الحجز: {str(e)}")
        return redirect('studentViewArticles')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/blog/appointment_details.html', context)


@login_required
def cancel_appointment(request, appointment_id):
    club = get_user_club(request.user)

    if not club:
        messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
        return redirect('index')

    appointment = get_object_or_404(SalonAppointment, id=appointment_id)
    if appointment.club != club:
        messages.error(request, "ليس لديك صلاحية لإلغاء هذا الموعد.")
        return redirect('studentViewArticles')

    try:
        booking = appointment.booking
        BookingService.objects.filter(booking=booking).delete()
        booking.delete()
        appointment.delete()

        messages.success(request, "تم إلغاء الحجز بنجاح")
    except:
        messages.error(request, "لم يتم العثور على حجز لهذا الموعد")

    return redirect('studentViewArticles')


@login_required
def add_to_cart(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity = int(request.POST.get('quantity', 1))

        # Get the product
        product = get_object_or_404(ProductsModel, id=product_id)

        # Check if stock is available
        if product.stock < quantity:
            return JsonResponse({
                'success': False,
                'message': 'لا يوجد مخزون كافي'
            })

        # Check if item already in cart
        cart_item, created = CartItem.objects.get_or_create(
            user=request.user,
            product=product,
            defaults={'quantity': quantity}
        )

        # If item already exists, update quantity
        if not created:
            cart_item.quantity += quantity
            cart_item.save()

        # Get cart count for navbar badge
        cart_count = CartItem.objects.filter(user=request.user).aggregate(
            total=Sum('quantity'))['total'] or 0

        return JsonResponse({
            'success': True,
            'message': 'تمت إضافة المنتج إلى السلة',
            'cart_count': cart_count
        })

    return JsonResponse({'success': False, 'message': 'Invalid request'})

# Cart Page View
@login_required
def cart(request):
    context = {}
    product_items = CartItem.objects.filter(user=request.user)
    service_items = ServiceCartItem.objects.filter(user=request.user)

    # Calculate total price
    product_total = sum(item.total_price for item in product_items)
    service_total = sum(item.total_price for item in service_items)
    total_price = product_total + service_total

    context = {
        'product_items': product_items,
        'service_items': service_items,
        'product_total': product_total,
        'service_total': service_total,
        'total_price': total_price
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/cart/cart.html', context)

# Update Cart Quantity
@login_required
def update_cart(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        action = request.POST.get('action')

        cart_item = get_object_or_404(CartItem, id=item_id, user=request.user)

        if action == 'increase':
            # Check stock availability
            if cart_item.quantity >= cart_item.product.stock:
                return JsonResponse({
                    'success': False,
                    'message': 'لا يوجد مخزون كافي'
                })

            cart_item.quantity += 1
            cart_item.save()

        elif action == 'decrease':
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
                cart_item.save()
            else:
                # Delete ServiceCartItem before deleting CartItem
                ServiceCartItem.objects.filter(cart_item=cart_item).delete()
                cart_item.delete()

        elif action == 'remove':
            # Delete ServiceCartItem before deleting CartItem
            ServiceCartItem.objects.filter(cart_item=cart_item).delete()
            cart_item.delete()

        # Recalculate totals
        remaining_items = CartItem.objects.filter(user=request.user)
        total_price = sum(item.total_price for item in remaining_items)
        cart_count = remaining_items.aggregate(total=Sum('quantity'))['total'] or 0

        return JsonResponse({
            'success': True,
            'total_price': float(total_price),
            'cart_count': cart_count,
            'item_total': float(cart_item.total_price) if action != 'remove' else 0
        })

    return JsonResponse({'success': False})


@login_required
def update_service_cart(request):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': 'Invalid request'})

    item_id = request.POST.get('item_id')
    action = request.POST.get('action')

    if not item_id or not action:
        return JsonResponse({'success': False, 'message': 'Missing parameters'})

    try:
        cart_item = ServiceCartItem.objects.get(id=item_id, user=request.user)

        if action == 'remove':
            try:
                service_id = cart_item.service.id

                booking_services = BookingService.objects.filter(
                    service__id=service_id,
                    booking__student__user=request.user
                )

                for booking_service in booking_services:
                    booking = booking_service.booking
                    appointment = booking.appointment

                    booking_service.delete()
                    booking.delete()
                    appointment.delete()

            except Exception as e:
                print(f"Error removing appointments: {str(e)}")

            cart_item.delete()

            product_total = get_cart_product_total(request.user)
            service_total = get_cart_service_total(request.user)
            total_price = product_total + service_total
            cart_count = get_cart_count(request.user)

            return JsonResponse({
                'success': True,
                'item_total': 0,
                'total_price': total_price,
                'product_total': product_total,
                'service_total': service_total,
                'cart_count': cart_count,
                'message': 'تم حذف الخدمة والموعد المرتبط بها بنجاح'
            })

        elif action == 'increase':
            cart_item.quantity += 1
            cart_item.save()
        elif action == 'decrease':
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
                cart_item.save()
            else:
                cart_item.delete()

        product_total = get_cart_product_total(request.user)
        service_total = get_cart_service_total(request.user)
        total_price = product_total + service_total
        cart_count = get_cart_count(request.user)

        return JsonResponse({
            'success': True,
            'cart_item_quantity': cart_item.quantity if action != 'remove' else 0,
            'item_total': cart_item.total_price if action != 'remove' else 0,
            'total_price': total_price,
            'product_total': product_total,
            'service_total': service_total,
            'cart_count': cart_count
        })

    except ServiceCartItem.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Item not found'})
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})

# Helper functions
def get_cart_product_total(user):
    return CartItem.objects.filter(user=user).aggregate(
        total=Sum(F('quantity') * F('product__price')))['total'] or 0

def get_cart_service_total(user):
    return ServiceCartItem.objects.filter(user=user).aggregate(
        total=Sum(F('quantity') * F('service__price')))['total'] or 0

def get_cart_count(user):
    product_count = CartItem.objects.filter(user=user).aggregate(Sum('quantity'))['quantity__sum'] or 0
    service_count = ServiceCartItem.objects.filter(user=user).count()
    return product_count + service_count



def get_cart_count(request):
    if request.user.is_authenticated:
        product_count = CartItem.objects.filter(user=request.user).aggregate(
            total=Sum('quantity'))['total'] or 0
        service_count = ServiceCartItem.objects.filter(user=request.user).aggregate(
            total=Sum('quantity'))['total'] or 0
        total_count = product_count + service_count
        return JsonResponse({'cart_count': total_count})
    return JsonResponse({'cart_count': 0})


@login_required
def checkout(request):
    product_items = CartItem.objects.filter(user=request.user)
    service_items = ServiceCartItem.objects.filter(user=request.user)

    if not product_items.exists() and not service_items.exists():
        messages.warning(request, 'سلة التسوق فارغة')
        return redirect('cart')

    out_of_stock_items = []
    for item in product_items:
        if item.quantity > item.product.stock:
            out_of_stock_items.append(item.product.title)

    if out_of_stock_items:
        messages.error(request, f'المنتجات التالية غير متوفرة بالكمية المطلوبة: {", ".join(out_of_stock_items)}')
        return redirect('cart')

    product_total = sum(item.total_price for item in product_items)
    service_total = sum(item.total_price for item in service_items)
    total_price = product_total + service_total

    context = {
        'product_items': product_items,
        'service_items': service_items,
        'product_total': product_total,
        'service_total': service_total,
        'total_price': total_price
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/cart/checkout.html', context)

# Process Order
@login_required
def place_order(request):
    context = {}
    if request.method == 'POST':
        product_items = CartItem.objects.filter(user=request.user)
        service_items = ServiceCartItem.objects.filter(user=request.user)

        if not product_items.exists() and not service_items.exists():
            messages.warning(request, 'سلة التسوق فارغة' if get_language() == 'ar' else 'Your cart is empty')
            return redirect('cart')

        lang = get_language()
        currency_symbol = 'ر.س' if lang == 'ar' else 'SAR'

        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        city = request.POST.get('city')
        region = request.POST.get('region')
        postal_code = request.POST.get('postal_code')
        notes = request.POST.get('notes', '')
        payment_method = request.POST.get('payment_method', 'credit_card')

        for item in product_items:
            if item.quantity > item.product.stock:
                msg = f"المنتج {item.product.title} غير متوفر بالكمية المطلوبة" if lang == 'ar' else f"The product {item.product.title} is not available in the requested quantity"
                messages.error(request, msg)
                return redirect('cart')

        product_total = sum(item.total_price for item in product_items)
        service_total = sum(item.total_price for item in service_items)
        total_price = product_total + service_total

        total_with_tax = total_price * Decimal(str(1.15))

        club = None
        if product_items.exists():
            club = product_items.first().product.club
        elif service_items.exists():
            club = service_items.first().service.club

        try:
            # Use transaction to ensure data consistency
            with transaction.atomic():
                order = Order.objects.create(
                    user=request.user,
                    club=club,
                    total_price=total_with_tax,
                    status='pending' if payment_method == 'cash_on_delivery' else 'confirmed',
                    payment_method=payment_method,
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    phone=phone,
                    address=address,
                    city=city,
                    region=region,
                    postal_code=postal_code,
                    notes=notes
                )

                # Track what the order contains
                has_products = product_items.exists()
                has_services = service_items.exists()

                # Process the order items
                for item in product_items:
                    OrderItem.objects.create(
                        order=order,
                        product=item.product,
                        quantity=item.quantity,
                        price=item.product.price
                    )

                    if payment_method == 'credit_card':
                        product = item.product
                        product.stock -= item.quantity
                        product.save()

                # Process service items and mark their appointments as paid if payment is credit card
                if payment_method == 'credit_card' and has_services:
                    try:
                        student_profile = request.user.userprofile.student_profile  # Adjust if needed

                        for item in service_items:
                            OrderItem.objects.create(
                                order=order,
                                service=item.service,
                                quantity=item.quantity,
                                price=item.service.price
                            )

                            # Find all bookings for this service and user with proper error handling
                            bookings = BookingService.objects.filter(
                                service=item.service,
                            ).select_related('booking', 'booking__appointment')

                            for booking_service in bookings:
                                # Add proper error handling for appointment relationship
                                try:
                                    if (booking_service.booking and
                                            hasattr(booking_service.booking, 'appointment') and
                                            booking_service.booking.appointment):

                                        appointment = booking_service.booking.appointment
                                        appointment.is_paid = True
                                        appointment.save()
                                except SalonAppointment.DoesNotExist:
                                    # Log this error but continue processing other items
                                    logger.error(f"Appointment not found for booking: {booking_service.booking.id}")
                                    continue

                            ServiceOrderModel.objects.create(
                                service=item.service,
                                student=request.user,
                                price=item.service.price * item.quantity,
                                is_complited=False,
                                end_datetime=timezone.now() + timezone.timedelta(days=item.service.subscription_days),
                                creation_date=timezone.now()
                            )
                    except Exception as e:
                        # Log the exception but don't interrupt the order process
                        logger.error(f"Error processing service appointments: {str(e)}")
                elif has_services:
                    # Process service items for cash on delivery
                    for item in service_items:
                        OrderItem.objects.create(
                            order=order,
                            service=item.service,
                            quantity=item.quantity,
                            price=item.service.price
                        )

                if payment_method == 'cash_on_delivery' and club:
                    customer_name = f"{first_name} {last_name}"
                    if has_products and has_services:
                        msg = f"طلب منتجات وخدمات جديد رقم #{order.id} بقيمة {total_with_tax} {currency_symbol} من العميل {customer_name}. يحتوي على {product_items.count()} منتج و {service_items.count()} خدمة - طريقة الدفع: الدفع عند الاستلام" if lang == 'ar' else f"New product & service order #{order.id} worth {total_with_tax} {currency_symbol} from {customer_name}. Includes {product_items.count()} product(s) and {service_items.count()} service(s) - Payment: Cash on Delivery"
                    elif has_products:
                        product_names = ", ".join([item.product.title for item in product_items][:3])
                        if product_items.count() > 3:
                            product_names += f" و{product_items.count() - 3} منتجات أخرى" if lang == 'ar' else f" and {product_items.count() - 3} more products"
                        msg = f"طلب منتجات جديد رقم #{order.id} بقيمة {total_with_tax} {currency_symbol} من العميل {customer_name}. يحتوي على {product_names} - طريقة الدفع: الدفع عند الاستلام" if lang == 'ar' else f"New product order #{order.id} worth {total_with_tax} {currency_symbol} from {customer_name}. Includes: {product_names} - Payment: Cash on Delivery"
                    else:
                        service_names = ", ".join([item.service.title for item in service_items][:3])
                        if service_items.count() > 3:
                            service_names += f" و{service_items.count() - 3} خدمات أخرى" if lang == 'ar' else f" and {service_items.count() - 3} more services"
                        msg = f"طلب خدمات جديد رقم #{order.id} بقيمة {total_with_tax} {currency_symbol} من العميل {customer_name}. يحتوي على {service_names} - طريقة الدفع: الدفع عند الاستلام" if lang == 'ar' else f"New service order #{order.id} worth {total_with_tax} {currency_symbol} from {customer_name}. Includes: {service_names} - Payment: Cash on Delivery"

                    Notification.objects.create(club=club, message=msg, is_read=False, created_at=timezone.now())

                # Clear the cart after successful order processing
                product_items.delete()
                service_items.delete()

                if payment_method == 'cash_on_delivery':
                    if has_products and has_services:
                        msg = 'تم إرسال طلب المنتجات والخدمات بنجاح وهو الآن قيد المراجعة. سيتم تأكيده من قبل المدير قريباً.' if lang == 'ar' else 'Your product and service order has been sent and is under review. It will be confirmed soon.'
                    elif has_products:
                        msg = 'تم إرسال طلب المنتجات بنجاح وهو الآن قيد المراجعة. سيتم تأكيده من قبل المدير قريباً.' if lang == 'ar' else 'Your product order has been sent and is under review. It will be confirmed soon.'
                    else:
                        msg = 'تم إرسال طلب الخدمات بنجاح وهو الآن قيد المراجعة. سيتم تأكيده من قبل المدير قريباً.' if lang == 'ar' else 'Your service order has been sent and is under review. It will be confirmed soon.'
                else:
                    if has_products and has_services:
                        msg = 'تم إتمام عملية شراء المنتجات والخدمات بنجاح' if lang == 'ar' else 'Product and service purchase completed successfully.'
                    elif has_products:
                        msg = 'تم إتمام عملية شراء المنتجات بنجاح' if lang == 'ar' else 'Product purchase completed successfully.'
                    else:
                        msg = 'تم إتمام عملية شراء الخدمات بنجاح' if lang == 'ar' else 'Service purchase completed successfully.'

                messages.success(request, msg)
                return redirect('order_details', order_id=order.id)

        except Exception as e:
            messages.error(request, f"حدث خطأ أثناء معالجة الطلب: {str(e)}" if lang == 'ar' else f"Error processing order: {str(e)}")
            return redirect('checkout')

    context['LANGUAGE_CODE'] = translation.get_language()
    return redirect('checkout')




@login_required
def add_service_to_cart(request):
    if request.method == 'POST':
        service_id = request.POST.get('service_id')
        quantity = int(request.POST.get('quantity', 1))

        if not service_id:
            return JsonResponse({'success': False, 'message': 'Service ID is required'})

        service = get_object_or_404(ServicesModel, id=service_id)

        # Remove the booking check if you want to allow any service to be added to cart
        # Alternatively, modify this condition based on your business requirements
        """
        booked_services = BookingService.objects.filter(
            booking__student=request.user.userprofile.student_profile,
            service=service
        )

        if not booked_services.exists():
            messages.error(request, 'لا يمكنك إضافة هذه الخدمة إلى السلة لأنها لم تُحجز.')
            return redirect('viewServicesSpecific', id=service_id)
        """

        cart_item, created = ServiceCartItem.objects.get_or_create(
            user=request.user,
            service=service,
            defaults={'quantity': quantity}
        )

        if not created:
            cart_item.quantity += quantity
            cart_item.save()

        product_count = CartItem.objects.filter(user=request.user).aggregate(
            total=Sum('quantity'))['total'] or 0
        service_count = ServiceCartItem.objects.filter(user=request.user).aggregate(
            total=Sum('quantity'))['total'] or 0
        cart_count = product_count + service_count

        messages.success(request, 'تمت إضافة الخدمة إلى السلة')

        # Redirect back to the service page or to cart
        return redirect('viewServicesSpecific', id=service_id)

    return redirect('viewServices')


@login_required
def update_service_cart(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        action = request.POST.get('action')

        cart_item = get_object_or_404(ServiceCartItem, id=item_id, user=request.user)

        if action == 'increase':
            cart_item.quantity += 1
            cart_item.save()

        elif action == 'decrease':
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
                cart_item.save()
            else:
                cart_item.delete()

        elif action == 'remove':
            cart_item.delete()

        remaining_service_items = ServiceCartItem.objects.filter(user=request.user)
        remaining_product_items = CartItem.objects.filter(user=request.user)

        service_total = sum(item.total_price for item in remaining_service_items)
        product_total = sum(item.total_price for item in remaining_product_items)
        total_price = service_total + product_total

        service_count = remaining_service_items.aggregate(total=Sum('quantity'))['total'] or 0
        product_count = remaining_product_items.aggregate(total=Sum('quantity'))['total'] or 0
        cart_count = service_count + product_count

        return JsonResponse({
            'success': True,
            'total_price': float(total_price),
            'cart_count': cart_count,
            'item_total': float(cart_item.total_price) if action != 'remove' else 0
        })

    return JsonResponse({'success': False})

@login_required
def view_student_profile(request):
    try:
        user_profile = request.user.userprofile
        student = user_profile.student_profile

        if not student:
            return render(request, 'error_page.html', {'message': 'No student profile found for this user.'})

        context = {
            'student': student,
            'userprofile': user_profile,
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'accounts/profiles/Student/ViewStudentProfile.html', context)

    except UserProfile.DoesNotExist:
        return render(request, 'error_page.html', {'message': 'User profile not found.'})
@login_required
def view_student_profile(request):
    try:
        user_profile = request.user.userprofile
        student = user_profile.student_profile

        if not student:
            return render(request, 'error_page.html', {'message': 'No student profile found for this user.'})

        context = {
            'student': student,
            'userprofile': user_profile,
        }

        return render(request, 'accounts/profiles/Student/ViewStudentProfile.html', context)

    except UserProfile.DoesNotExist:
        return render(request, 'error_page.html', {'message': 'User profile not found.'})

class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ['full_name', 'phone', 'birthday', 'about']
        widgets = {
            'full_name': forms.TextInput(attrs={'class': 'mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm'}),
            'phone': forms.TextInput(attrs={'class': 'mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm'}),
            'birthday': forms.DateInput(attrs={'type': 'date', 'class': 'mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm'}),
            'about': forms.Textarea(attrs={'rows': 4, 'class': 'mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm'})
        }

@login_required
def edit_student_profile(request):
    try:
        user_profile = request.user.userprofile
        student = user_profile.student_profile

        if not student:
            return render(request, 'error_page.html', {'message': 'No student profile found for this user.'})

        if request.method == 'POST':
            form = StudentProfileForm(request.POST, instance=student)

            if form.is_valid():
                form.save()

                if 'profile_image_base64' in request.FILES:
                    image_file = request.FILES['profile_image_base64']
                    encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
                    user_profile.profile_image_base64 = f"data:image/{image_file.content_type.split('/')[-1]};base64,{encoded_string}"
                    user_profile.save()

                return redirect('student_profile')
        else:
            form = StudentProfileForm(instance=student)

        context = {
            'form': form,
            'student': student,
            'user_profile': user_profile,
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'accounts/settings/Student/EditStudentProfile.html', context)

    except UserProfile.DoesNotExist:
        return render(request, 'error_page.html', {'message': 'User profile not found.'})


@login_required
def order_details(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    order_items = OrderItem.objects.filter(order=order)

    context = {
        'order': order,
        'order_items': order_items,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/orders/order_details.html', context)

@login_required
def student_orders(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')

    context = {
        'orders': orders
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'student/orders/student_orders.html', context)