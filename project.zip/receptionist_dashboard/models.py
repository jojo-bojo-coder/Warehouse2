from django.db import models
from accounts.models import StudentProfile
from students.models import ServicesModel

class SalonBooking(models.Model):
    appointment = models.OneToOneField(
        'club_dashboard.SalonAppointment',
        on_delete=models.CASCADE,
        related_name='booking'
    )
    employee = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        service_names = ", ".join([bs.service.title for bs in self.services.all()])
        return f"{self.student.full_name} - {service_names} - {self.appointment.day}"

    class Meta:
        ordering = ['-created_at']

class BookingService(models.Model):
    """Model to handle multiple services per booking"""
    booking = models.ForeignKey(
        SalonBooking,
        on_delete=models.CASCADE,
        related_name='services'
    )
    service = models.ForeignKey(
        ServicesModel,
        on_delete=models.CASCADE,
        related_name='booking_services'
    )
    coach_name = models.CharField(max_length=255, blank=True, null=True)
    coach_id = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return f"{self.service.title} for {self.booking.student.full_name}"

    class Meta:
        unique_together = ('booking', 'service')