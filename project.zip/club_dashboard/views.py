from django.shortcuts import render, redirect,get_object_or_404
from accounts.models import UserProfile, StudentProfile, CoachProfile ,ReceptionistProfile,AdministrativeProfile
from django.contrib.auth.models import User
from .forms import StudentProfileForm, CoachProfileForm, ArticleModelForm, ServicesModelForm, ServicesClassificationModelForm, ProductsModelForm, ProductsClassificationModelForm,ReceptionistProfileForm,ProductShipmentForm,AdministratorProfileForm
from accounts.forms import ReceptionistSignupForm,AdministratorSignupForm
from students.models import Blog, ServicesModel, ServicesClassificationModel, ProductsModel, ProductsClassificationModel, ProductsImage, ServicesImage,Order,OrderItem,ServiceOrderModel
from django.utils import timezone
# Create your views here.
from django.contrib import messages  # ✅ Fix missing import
from .forms import DirectorProfileForm  # ✅ Fix missing import
from accounts.models import DirectorProfile  # ✅ Add this import
from .models import Notification  # Import the Notification model
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from accounts.models import UserProfile
from club_dashboard.models import Notification  # ✅ Import Notification Model
from .utils import send_notification  # ✅ Import notification function
from django.contrib.auth.decorators import login_required  # ✅ Fix missing import
from django.db.models import Avg
from club_dashboard.models import Review  # ✅ Import Review model from students app
from .models import SalonAppointment,ProductShipment
from django.shortcuts import render
from django.db.models import Sum, F, FloatField, Case, When, IntegerField, Value
from django.db.models.functions import Cast
from .models import ProductsModel ,ProductImg
from django.utils import timezone
from django.contrib import messages
from .forms import ProductsModelForm
from django.core.paginator import Paginator
import base64
import time
import decimal
from django.core.files.base import ContentFile
from django.utils import timezone
from .forms import ServicesModelForm
from datetime import datetime, timedelta
from django.db import models , transaction
from receptionist_dashboard.models import BookingService
from django.template.loader import render_to_string
import json
from django.http import HttpResponseForbidden
from django.urls import reverse
from accounts.models import UserProfile,DirectorProfile
from .forms import DirectorProfileForm
from django.utils import translation
from receptionist_dashboard.models import SalonBooking
import openpyxl
from openpyxl.styles import Font, Alignment
from django.http import HttpResponse
from django.utils.translation import gettext as _
from django.db.models import Count

# Helper function to get user's club
def get_user_club(user):
    user_profile = user.userprofile
    club = None
    if user_profile.account_type == '3':  # Student
        club = user_profile.student_profile.club if hasattr(user_profile, 'student_profile') else None
    elif user_profile.account_type == '4':  # Coach
        club = user_profile.Coach_profile.club if hasattr(user_profile, 'Coach_profile') else None
    elif user_profile.account_type == '2':  # Director
        club = user_profile.director_profile.club if hasattr(user_profile, 'director_profile') else None
    elif user_profile.account_type == '5':  # Receptionist
        club = user_profile.receptionist_profile.club if hasattr(user_profile, 'receptionist_profile') else None
    return club

@login_required
def club_dashboard_index(request):
    context = {}
    user = request.user

    # ✅ Ensure the user has a valid director profile
    if not hasattr(user, 'userprofile') or not user.userprofile.director_profile:
        messages.error(request, "Unauthorized access.")
        return redirect('home')

    # ✅ Get the correct club for the director
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    club_name = club.name

    club_admin = user.userprofile.director_profile
    # ✅ Get directors linked through UserProfile
    directors = UserProfile.objects.filter(account_type='6', administrator_profile__club=club)
    director_count = directors.count()

    # ✅ Fetch students and coaches from this club
    students = StudentProfile.objects.filter(club=club)

    # Map for Arabic labels
    manual_status_labels = {
        'trial': 'تجريبي',
        'active': 'نشط',
        'expiring_soon': 'سينتهي قريبًا',
        'expired': 'منتهي',
    }

    # Get counts for each manual status
    manual_status_counts = StudentProfile.objects.filter(club=club) \
        .values('manual_status') \
        .annotate(count=Count('manual_status'))

    manual_status_dict = {status: 0 for status in manual_status_labels.keys()}

    for entry in manual_status_counts:
        key = entry['manual_status'] or 'trial'
        if key in manual_status_dict:
            manual_status_dict[key] = entry['count']

    manual_chart_labels = [manual_status_labels[k] for k in manual_status_dict.keys()]
    manual_chart_data = list(manual_status_dict.values())

    student_count = students.count()

    coaches = CoachProfile.objects.filter(club=club)
    coach_count = coaches.count()

    notifications = Notification.objects.filter(club=club, is_read=False).order_by('-created_at')
    unread_count = notifications.count()
    notifications.update(is_read=True)

    active_count, expiring_soon_count, expired_count, trial_count = 0, 0, 0, 0
    for student in students:
        status = student.get_subscription_status()
        if status == "active":
            active_count += 1
        elif status == "expiring_soon":
            expiring_soon_count += 1
        elif status == "trial":
            trial_count += 1
        else:
            expired_count += 1

    total_students = max(1, active_count + expiring_soon_count + expired_count + trial_count)

    def calc_percent(v, total):
        return round((v / total) * 100, 2) if total > 0 else 0

    active_percentage = calc_percent(active_count, total_students)
    expiring_soon_percentage = calc_percent(expiring_soon_count, total_students)
    expired_percentage = calc_percent(expired_count, total_students)
    trial_percentage = calc_percent(trial_count, total_students)

    top_rated_coaches = (
        CoachProfile.objects.filter(club=club)
        .annotate(avg_rating=Avg('coach_reviews__rating'))
        .filter(avg_rating__isnull=False)
        .order_by('-avg_rating')[:5]
    )

    top_reviews = (
        Review.objects.filter(coach__club=club)
        .order_by('-rating', '-created_at')[:5]
    )

    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if not start_date:
        start_date = (timezone.now() - timezone.timedelta(days=30)).strftime('%Y-%m-%d')
    if not end_date:
        end_date = timezone.now().strftime('%Y-%m-%d')

    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
        end_date_obj = end_date_obj.replace(hour=23, minute=59, second=59)
    except ValueError:
        start_date_obj = timezone.now() - timezone.timedelta(days=30)
        end_date_obj = timezone.now()

    orders = Order.objects.filter(
        club=club,
        created_at__gte=start_date_obj,
        created_at__lte=end_date_obj
    ).order_by('-created_at')

    total_revenue = int(orders.filter(status__in=['confirmed', 'completed']).aggregate(Sum('total_price'))['total_price__sum'] or 0)

    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/index.html', {
        'clubName': club_name,
        'students': students,
        'coaches': coaches,
        'directors': directors,
        'director_count': director_count,
        'coach_count': coach_count,
        'student_count': student_count,
        'active_count': active_count,
        'expiring_soon_count': expiring_soon_count,
        'expired_count': expired_count,
        'trial_count': trial_count,
        'active_percentage': active_percentage,
        'expiring_soon_percentage': expiring_soon_percentage,
        'expired_percentage': expired_percentage,
        'trial_percentage': trial_percentage,
        'notifications': notifications,
        'unread_count': unread_count,
        'top_rated_coaches': top_rated_coaches,
        'top_reviews': top_reviews,
        'total_revenue': total_revenue,
        'club_admin': club_admin,
        'manual_chart_labels': manual_chart_labels,
        'manual_chart_data': manual_chart_data,
    })



def viewStudents(request):
    context ={}
    """Displays all students in the club."""
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    students = UserProfile.objects.filter(
        account_type='3', 
        student_profile__club=club
    ).select_related('user', 'student_profile')

    # ✅ Enrich each student with subscription status
    for student in students:
        profile = student.student_profile
        if profile and hasattr(profile, 'get_subscription_status'):
            student.subscription_status = profile.get_subscription_status()
            student.manual_status_display = profile.get_manual_status_display()
        else:
            student.subscription_status = "unknown"
            student.manual_status_display = "-"
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/students/viewStudents.html', {'students': students,'club': club})




def export_students_excel(request):
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    students = UserProfile.objects.filter(
        account_type='3',
        student_profile__club=club
    ).select_related('user', 'student_profile')

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "اللاعبين"

    arabic_font = Font(name='Arial', size=12)
    right_align = Alignment(horizontal='right')

    headers = [
        _('Username'), _('Email'), _('Full Name'),
        _('Phone'), _('Birthday'), _('Subscription Status')
    ]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = arabic_font
        cell.alignment = right_align

    for student in students:
        profile = student.student_profile
        subscription = profile.get_subscription_status() if hasattr(profile, 'get_subscription_status') else "unknown"

        row = [
            student.user.username,
            student.user.email,
            profile.full_name if profile else '',
            profile.phone if profile else '',
            str(profile.birthday) if profile and profile.birthday else '',
            subscription
        ]
        ws.append(row)
        for cell in ws[ws.max_row]:
            cell.font = arabic_font
            cell.alignment = right_align

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    )
    response['Content-Disposition'] = 'attachment; filename=players.xlsx'
    wb.save(response)
    return response




def addStudent(request):
    context ={}
    """Adds a new student to the club."""
    user = request.user

    # ✅ Ensure user is a director
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    form = StudentProfileForm()

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # ✅ Prevent duplicate username and email
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('addStudent')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already in use.")
            return redirect('addStudent')

        form = StudentProfileForm(request.POST)
        if form.is_valid():
            # ✅ Create new user
            student = User.objects.create(username=username, email=email)
            if password:
                student.set_password(password)
            student.save()

            # ✅ Create and link Student Profile
            student_profile = form.save(commit=False)
            student_profile.user = student  # 🔥 FIXED: Set user reference
            student_profile.club = club
            student_profile.save()

            # ✅ Create UserProfile entry
            UserProfile.objects.create(user=student, account_type='3', student_profile=student_profile)

            # ✅ Send notification
            send_notification(user, club, f"📢 New Player {username} has joined {club.name}.")

            messages.success(request, "CLient added successfully.")
            return redirect('viewStudents')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/students/addStudent.html', {'form': form,'club': club})


@login_required
def editStudent(request, id):
    context = {}
    """Edits an existing student's details."""
    user = request.user

    # ✅ Ensure user is a director
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    student_profile = get_object_or_404(StudentProfile, id=id)
    student = get_object_or_404(User, userprofile__student_profile=student_profile)

    form = StudentProfileForm(instance=student_profile)

    if request.method == 'POST':
        new_username = request.POST.get('username')
        new_email = request.POST.get('email')
        password = request.POST.get('password')

        form = StudentProfileForm(request.POST, instance=student_profile)
        if form.is_valid():
            # ✅ Update student details
            student.username = new_username
            student.email = new_email
            if password:
                student.set_password(password)
            student.save()

            student_profile = form.save(commit=False)
            student_profile.user = student  # 🔥 FIXED: Ensure user link remains
            student_profile.save()

            # ✅ Send notification
            send_notification(user, club, f"📝 Player {student.username}'s profile has been updated.")

            messages.success(request, "CLient profile updated successfully.")
            return redirect('viewStudents')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/students/editStudent.html', {
        'form': form,
        'student': student,
        'club': club,
    })



@login_required
def deleteStudent(request, id):
    """Deletes a student from the club."""
    user = request.user

    # ✅ Ensure user is a director
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    student_profile = get_object_or_404(StudentProfile, id=id)
    student = get_object_or_404(User, userprofile__student_profile=student_profile)

    student_name = student.username

    # ✅ Delete student profile and user account
    student_profile.delete()
    student.delete()

    # ✅ Send notification
    send_notification(user, club, f"🗑️ Player {student_name} has been removed from the Club.")

    messages.success(request, "CLient has been deleted successfully.")
    return redirect('viewStudents')


def viewCoachs(request):
    context ={}
    """Displays a list of coaches belonging to the club."""
    user = request.user

    coach_userprofile = UserProfile.objects.filter(
        account_type='4',
        Coach_profile__club=getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    )
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/coachs/viewCoachs.html', {'coach_userprofile': coach_userprofile,'club':getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)})


def export_coaches_excel(request):
    user = request.user

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    coaches = UserProfile.objects.filter(
        account_type='4',
        Coach_profile__club=club
    ).select_related('user', 'Coach_profile')

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = _("Coaches")

    font = Font(name='Arial', size=12)
    align = Alignment(horizontal='right')

    headers = [
        _('Username'),
        _('Email'),
        _('Full Name'),
        _('Phone'),
    ]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = font
        cell.alignment = align

    for coach in coaches:
        profile = coach.Coach_profile
        row = [
            coach.user.username,
            coach.user.email,
            profile.full_name if profile else '',
            profile.phone if profile else '',
        ]
        ws.append(row)
        for cell in ws[ws.max_row]:
            cell.font = font
            cell.alignment = align

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename=coaches.xlsx'
    wb.save(response)
    return response

@login_required
def addCoach(request):
    context = {}
    """Adds a new coach to the club."""
    user = request.user

    # ✅ Ensure user is a director
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    form = CoachProfileForm()

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # ✅ Prevent duplicate username and email
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('addCoach')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already in use.")
            return redirect('addCoach')

        form = CoachProfileForm(request.POST)
        if form.is_valid():
            # ✅ Create new user
            coach = User.objects.create(username=username, email=email)
            if password:
                coach.set_password(password)
            coach.save()

            # ✅ Create coach profile & associate with club
            coach_profile = form.save(commit=False)
            coach_profile.club = club
            coach_profile.save()

            # ✅ Create UserProfile entry
            UserProfile.objects.create(user=coach, account_type='4', Coach_profile=coach_profile)

            # ✅ Send notification
            send_notification(user, club, f"📢 A new Coach {username} has joined {club.name}.")

            messages.success(request, "Employee added successfully.")
            return redirect('viewCoachs')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/coachs/addCoach.html', {'form': form,'club': club})

@login_required
def editCoach(request, id):
    context = {}
    """Edits an existing coach's details."""
    user = request.user

    # ✅ Ensure user is a director
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    coach_profile = get_object_or_404(CoachProfile, id=id)
    coach = get_object_or_404(User, userprofile__Coach_profile=coach_profile)

    form = CoachProfileForm(instance=coach_profile)

    if request.method == 'POST':
        new_username = request.POST.get('username')
        new_email = request.POST.get('email')
        password = request.POST.get('password')

        form = CoachProfileForm(request.POST, instance=coach_profile)
        if form.is_valid():
            # ✅ Check if username or email was changed
            username_changed = new_username != coach.username
            email_changed = new_email != coach.email

            # ✅ Update coach details
            coach.username = new_username
            coach.email = new_email
            if password:
                coach.set_password(password)
            coach.save()

            form.save()

            # ✅ Send notification if changes were made
            notification_message = f"📝 Coach {coach.username}'s profile was updated."
            if username_changed or email_changed:
                notification_message += " (Username/Email updated.)"

            send_notification(user, club, notification_message)

            messages.success(request, "Employee profile updated successfully.")
            return redirect('viewCoachs')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/coachs/editCoach.html', {
        'form': form,
        'coach': coach,
        'club':club,
    })

@login_required
def deleteCoach(request, id):
    """Deletes a coach from the club."""
    user = request.user

    # ✅ Ensure user is a director
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    coach_profile = get_object_or_404(CoachProfile, id=id)
    coach = get_object_or_404(User, userprofile__Coach_profile=coach_profile)

    coach_name = coach.username

    # ✅ Delete coach profile and user account
    coach_profile.delete()
    coach.delete()

    # ✅ Send notification
    send_notification(user, club, f"🗑️ Coach {coach_name} has been removed from the Club.")

    messages.success(request, "Employee has been deleted successfully.")
    return redirect('viewCoachs')



    
def viewAdmins(request):
    user = request.user
    admin_userprofile = UserProfile.objects.filter(account_type='3', Admin_profile__club=user.userprofile.director_profile.club)
    return render(request, 'club_dashboard/admins/viewAdmins.html', {'admin_userprofile': admin_userprofile})
def addAdmin(request):
    user = request.user
    club = user.userprofile.director_profile.club

    form = AdminProfileForm()
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        form = AdminProfileForm(request.POST)
        if form.is_valid():
            admin = User.objects.create(username=username, email=email)
            if password:
                admin.set_password(password)
            admin.save()

            admin_profile = form.save()
            admin_profile.club = club
            admin_profile.save()

            userprofile = UserProfile.objects.create(user=admin, account_type='3', Admin_profile=admin_profile)
            userprofile.save()

            return redirect('viewAdmins')

    return render(request, 'club_dashboard/admins/addAdmin.html', {'form': form})

def editAdmin(request, id):
    admin_profile = AdminProfile.objects.get(id=id)
    form = AdminProfileForm(instance=admin_profile)
    admin = User.objects.get(userprofile__Admin_profile=admin_profile)
    username = admin.username
    email = admin.email

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        form = AdminProfileForm(request.POST, instance=admin_profile)
        if form.is_valid():
            admin.username = username
            admin.email = email
            if password:
                admin.set_password(password)
            admin.save()

            admin_profile = form.save()

            return redirect('viewAdmins')

    return render(request, 'club_dashboard/admins/editAdmin.html', {'admin': admin, 'form': form, 'email': email, 'username': username})

def deleteAdmin(request, id):
    admin_profile = AdminProfile.objects.get(id=id)
    admin = User.objects.get(userprofile__Admin_profile=admin_profile)

    admin_profile.delete()
    admin.delete()

    return redirect('viewAdmins')




def addProduct(request):
    context = {}
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    form = ProductsModelForm()

    if request.method == 'POST':
        form = ProductsModelForm(data=request.POST)
        if form.is_valid():
            ser = form.save(commit=False)
            ser.club = club
            ser.creator = user
            ser.creation_date = timezone.now()
            ser.save()

            profile_imgs = request.POST.getlist('profile_imgs')
            for img_data in profile_imgs:
                format, imgstr = img_data.split(';base64,') if ';base64,' in img_data else ('', img_data)
                ext = format.split('/')[-1] if '/' in format else 'png'

                from django.core.files.base import ContentFile
                import base64, uuid

                data = ContentFile(base64.b64decode(imgstr), name=f'{uuid.uuid4()}.{ext}')

                ProductImg.objects.create(
                    product=ser,
                    img=data
                )

            messages.success(request, 'تم إضافة المنتج بنجاح!')
            return redirect('viewProducts')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/products/ProductsStock/addProductStock.html', {'form': form,'club': club})

def editProduct(request, id):
    context = {}
    product = ProductsModel.objects.get(id=id)
    profile_img_objs = ProductImg.objects.filter(product=product)
    form = ProductsModelForm(instance=product)
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    if request.method == 'POST':
        form = ProductsModelForm(data=request.POST, instance=product)
        if form.is_valid():
            profile_imgs = request.POST.getlist('profile_imgs')
            images_changed = request.POST.get('images_changed', 'false') == 'true'

            updated_product = form.save(commit=False)
            updated_product.updated_at = timezone.now()
            updated_product.save()
            form.save_m2m()

            if images_changed:
                ProductImg.objects.filter(product=product).delete()

                for img_data in profile_imgs:
                    if img_data.startswith('data:image'):
                        format, imgstr = img_data.split(';base64,')
                        ext = format.split('/')[-1]

                        import uuid
                        filename = f"{uuid.uuid4()}.{ext}"

                        from django.core.files.base import ContentFile
                        import base64
                        data = ContentFile(base64.b64decode(imgstr))

                        img_obj = ProductImg(product=product)
                        img_obj.img.save(filename, data, save=False)
                        img_obj.save()

            messages.success(request, 'تم تعديل المنتج بنجاح')
            return redirect('viewProducts')

    context = {
        'form': form,
        'profile_imgs': profile_img_objs,
        'club' :club,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/products/ProductsStock/editProductStock.html', context)

def viewProducts(request):
    context = {}
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    products = ProductsModel.objects.filter(club=club)
    total_products = products.count()

    total_value = 0
    low_stock_count = 0
    out_of_stock_count = 0
    expiring_soon_count = 0
    expired_count = 0
    low_stock_threshold = 10

    for product in products:
        product_value = product.price * product.stock
        total_value += product_value

        if 0 < product.stock <= low_stock_threshold:
            low_stock_count += 1

        if product.stock == 0:
            out_of_stock_count += 1

        if product.is_expiring_soon:
            expiring_soon_count += 1

        if product.is_expired:
            expired_count += 1

    paginator = Paginator(products, 6)
    page_number = request.GET.get('page', 1)
    paginated_products = paginator.get_page(page_number)

    context = {
        'products': paginated_products,
        'total_products': total_products,
        'total_value': total_value,
        'low_stock_count': low_stock_count,
        'out_of_stock_count': out_of_stock_count,
        'expiring_soon_count': expiring_soon_count,
        'expired_count': expired_count,
        'low_stock_threshold': low_stock_threshold,
        'club':club
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/products/ProductsStock/viewProductsStock.html', context)


def DeleteProduct(request, id):
    art = get_object_or_404(ProductsModel, id=id)
    art.delete()
    messages.success(request, 'تم حذف المنتج بنجاح!')
    return redirect('viewProducts')

def addProductClassification(request):
    user = request.user
    club = user.userprofile.director_profile.club
    form = ProductsClassificationModelForm()
    if request.method == 'POST':
        form = ProductsClassificationModelForm(data=request.POST)
        if form.is_valid():
            cla = form.save(commit=False)
            cla.club = club
            cla.creator = user
            cla.creation_date = timezone.now()
            cla.save()

    return render(request, 'club_dashboard/products/Classification/addClassification.html', {'form':form})

def editProductClassification(request, id):
    cla = ProductsClassificationModel.objects.get(id=id)
    form = ProductsClassificationModelForm(instance=cla)
    if request.method == 'POST':
        form = ProductsClassificationModelForm(data=request.POST, instance=cla)
        if form.is_valid():
            form.save()
    return render(request, 'club_dashboard/products/Classification/editClassification.html', {'form':form})

def viewProductsClassification(request):
    classifications = ProductsClassificationModel.objects.all()

    return render(request, 'club_dashboard/products/Classification/viewClassification.html', {'classifications':classifications})

def DeleteProductsClassification(request, id):
    art = ProductsClassificationModel.objects.get(id=id)
    art.delete()
    return redirect('viewProductsClassification')


#Services
def addServices(request):
    context = {}
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    coaches = CoachProfile.objects.filter(club=club)
    form = ServicesModelForm()
    form.fields['coaches'].queryset = coaches

    if request.method == 'POST':
        form = ServicesModelForm(data=request.POST)
        form.fields['coaches'].queryset = coaches
        if form.is_valid():
            ser = form.save(commit=False)
            ser.club = club
            ser.creator = user
            ser.creation_date = timezone.now()

            ser.age_from = 0
            ser.age_to = 100
            ser.subscription_days = 30

            duration = request.POST.get('duration')
            if duration:
                ser.duration = int(duration)
            else:
                ser.duration = 0

            discounted_price = request.POST.get('discounted_price')
            if discounted_price and discounted_price.strip():
                ser.discounted_price = decimal.Decimal(discounted_price)

            ser.save()
            form.save_m2m()

            image_data = request.POST.get('service_image_data')
            if image_data and image_data.startswith('data:image'):
                format, imgstr = image_data.split(';base64,')
                ext = format.split('/')[-1]

                filename = f"service_{ser.id}_{int(time.time())}.{ext}"
                temp_file = ContentFile(base64.b64decode(imgstr), name=filename)

                ser.image.save(filename, temp_file, save=True)

            return redirect('viewServices')
        else:
            print(form.errors)
    context['LANGUAGE_CODE'] = translation.get_language()
    selected_coach_ids = request.POST.getlist('coaches') if request.method == 'POST' else []
    return render(request, 'club_dashboard/services/addServices.html', {'form': form,'selected_coach_ids': selected_coach_ids,'club': club})



def editServices(request, id):
    context = {}
    ser = ServicesModel.objects.get(id=id)
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    coaches = CoachProfile.objects.filter(club=club)
    form = ServicesModelForm(instance=ser)
    form.fields['coaches'].queryset = coaches

    if request.method == 'POST':
        form = ServicesModelForm(data=request.POST, instance=ser)
        form.fields['coaches'].queryset = coaches
        if form.is_valid():
            ser = form.save(commit=False)
            ser.creation_date = timezone.now()

            duration = request.POST.get('duration')
            ser.duration = int(duration) if duration else 0

            discounted_price = request.POST.get('discounted_price')
            if discounted_price and discounted_price.strip():
                ser.discounted_price = decimal.Decimal(discounted_price)
            else:
                ser.discounted_price = None

            # Check if the current image should be removed
            remove_current_image = request.POST.get('remove_current_image')
            if remove_current_image == 'true' and ser.image:
                # Delete the old image file
                ser.image.delete(save=False)

            # Process new image upload if available
            image_data = request.POST.get('service_image_data')
            if image_data and image_data.startswith('data:image'):
                # Get the format and the actual base64 data
                format, imgstr = image_data.split(';base64,')
                ext = format.split('/')[-1]

                # Generate filename and save path
                filename = f"service_{ser.id}_{int(time.time())}.{ext}"
                temp_file = ContentFile(base64.b64decode(imgstr), name=filename)

                # If there's an existing image, delete it first
                if ser.image:
                    ser.image.delete(save=False)

                # Save to the model's ImageField
                ser.image.save(filename, temp_file, save=False)

            ser.save()
            form.save_m2m()
            return redirect('viewServices')
        else:
            print(form.errors)
    context['LANGUAGE_CODE'] = translation.get_language()
    selected_coach_ids = request.POST.getlist('coaches') if request.method == 'POST' else []
    return render(request, 'club_dashboard/services/editServices.html', {'form': form,'selected_coach_ids': selected_coach_ids,'club':club})


def viewServices(request):
    context = {}
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    services = ServicesModel.objects.filter(club= getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    )

    if services:
        avg_price = sum(service.discounted_price or service.price for service in services) / len(services)
        avg_price = round(avg_price, 1)

        avg_duration = sum(service.duration for service in services) / len(services)
        avg_duration_hours = int(avg_duration // 60)
        avg_duration_minutes = int(avg_duration % 60)
    else:
        avg_price = 0
        avg_duration_hours = 0
        avg_duration_minutes = 0

    context = {
        'services': services,
        'avg_price': avg_price,
        'avg_duration_hours': avg_duration_hours,
        'avg_duration_minutes': avg_duration_minutes,
        'club':club,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/services/viewServices.html', context)

def DeleteServices(request, id):
    art = ServicesModel.objects.get(id=id)
    art.delete()
    return redirect('viewServices')

def addServicesClassification(request):
    user = request.user
    club = user.userprofile.director_profile.club
    form = ServicesClassificationModelForm()
    if request.method == 'POST':
        form = ServicesClassificationModelForm(data=request.POST)
        if form.is_valid():
            cla = form.save(commit=False)
            cla.club = club
            cla.creator = user
            cla.creation_date = timezone.now()
            cla.save()


    return render(request, 'club_dashboard/services/Classification/addClassification.html', {'form':form})

def editServicesClassification(request, id):
    cla = ServicesClassificationModel.objects.get(id=id)
    form = ServicesClassificationModelForm(instance=cla)
    if request.method == 'POST':
        form = ServicesClassificationModelForm(data=request.POST, instance=cla)
        if form.is_valid():
            form.save()

    return render(request, 'club_dashboard/services/Classification/editClassification.html', {'form':form})

def viewServicesClassification(request):
    classifications = ServicesClassificationModel.objects.all()
    return render(request, 'club_dashboard/services/Classification/viewClassification.html', {'classifications':classifications})

def DeleteServicesClassification(request, id):
    art = ServicesClassificationModel.objects.get(id=id)
    art.delete()
    return redirect('viewServicesClassification')

#Blog
def addArticle(request):
    context = {}
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    form = ArticleModelForm()
    if request.method == 'POST':
        form = ArticleModelForm(data=request.POST,files=request.FILES)
        if form.is_valid():

            art = form.save(commit=False)
            art.club = club
            art.creator = user
            art.creation_date = timezone.now()
            art.save()
            return redirect('viewArticles')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/blog/addArticle.html', {'form':form,'club': club})

def editArticle(request, id):
    context = {}
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    art = Blog.objects.get(id=id)
    form = ArticleModelForm(instance=art)
    try:
        art = Blog.objects.get(id=id, club=club)
        form = ArticleModelForm(instance=art)

        if request.method == 'POST':
            form = ArticleModelForm(data=request.POST, files=request.FILES, instance=art)
            if form.is_valid():
                form.save()
                return redirect('viewArticles')
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'club_dashboard/blog/editArticle.html', {'form': form,'club':club})

    except Blog.DoesNotExist:
        return redirect('viewArticles')

def viewArticles(request):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    arts = Blog.objects.filter(club=club)  # Only show articles from this club

    # Get statistics for the dashboard
    total_articles = arts.count()
    current_month = timezone.now().month
    current_year = timezone.now().year
    new_articles_this_month = arts.filter(
        creation_date__month=current_month,
        creation_date__year=current_year
    ).count()

    # Get most popular articles (assuming you have a views or likes field)
    # If not, you can add this feature later
    popular_articles = arts.order_by('-id')[:3]

    context = {
        'arts': arts,
        'total_articles': total_articles,
        'new_articles_this_month': new_articles_this_month,
        'popular_articles': popular_articles.count(),
        'club':club,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/blog/viewArticless.html', context)

def DeleteArticle(request, id):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    try:
        art = Blog.objects.get(id=id, club=club)
        art.delete()
    except Blog.DoesNotExist:
        pass

    return redirect('viewArticles')

def viewDirectors(request):
    context = {}
    user = request.user
    userprofile = getattr(user, 'userprofile', None)

    club = None
    if userprofile:
        if userprofile.account_type == '2' and userprofile.director_profile:
            club = userprofile.director_profile.club

    if club:
        administrator_userprofile = UserProfile.objects.filter(
            account_type='6',
            administrator_profile__club=club
        )
    else:
        administrator_userprofile = UserProfile.objects.none()

    context['LANGUAGE_CODE'] = translation.get_language()
    context['administrator_userprofile'] = administrator_userprofile
    return render(request, 'club_dashboard/directors/viewDirectors.html', context)
    
def addDirector(request):
    context = {}
    user = request.user

    # ✅ Ensure the user is a director before proceeding
    if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
        messages.error(request, "Unauthorized access.")
        return redirect('club_dashboard_index')  # 🔹 Fix: Redirect to the club dashboard if unauthorized

    club = user.userprofile.director_profile.club  # Get the current director’s club
    form = AdministratorProfileForm

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # ✅ Ensure username and email are unique
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('addDirector')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already in use.")
            return redirect('addDirector')

        form = AdministratorProfileForm(request.POST)
        if form.is_valid():
            # ✅ Create user
            administrator_user = User.objects.create(username=username, email=email)
            if password:
                administrator_user.set_password(password)
            administrator_user.save()

            # ✅ Create administrator profile and assign the club
            administrator_profile = form.save(commit=False)
            administrator_profile.club = club
            administrator_profile.save()

            # ✅ Create user profile
            UserProfile.objects.create(user=administrator_user, account_type='6', administrator_profile=administrator_profile)

            messages.success(request, "Administrator added successfully.")
            return redirect('viewDirectors')  # 🔹 Fix: Redirect to the correct club dashboard page
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/directors/addDirector.html', {'form': form})


def editDirector(request, id):
    context = {}
    administrator_profile = get_object_or_404(AdministrativeProfile, id=id)
    administrator = get_object_or_404(User, userprofile__administrator_profile=administrator_profile)

    form = AdministratorProfileForm(instance=administrator_profile)
    username = administrator.username
    email = administrator.email

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        full_name = request.POST.get('full_name')
        phone = request.POST.get('phone')
        about = request.POST.get('about')
        password = request.POST.get('password')

        form = AdministratorProfileForm(request.POST, instance=administrator_profile)
        
        if form.is_valid():
            # Ensure the username is unique (excluding the current user)
            if User.objects.exclude(id=administrator.id).filter(username=username).exists():
                messages.error(request, "Username already exists.")
                return redirect('editDirector', id=id)

            # Ensure the email is unique (excluding the current user)
            if User.objects.exclude(id=administrator.id).filter(email=email).exists():
                messages.error(request, "Email is already in use.")
                return redirect('editDirector', id=id)

            # Update the User fields
            administrator.username = username
            administrator.email = email
            if password:
                administrator.set_password(password)  # Change password if provided
            administrator.save()

            # Update the DirectorProfile fields
            administrator_profile.full_name = full_name
            administrator_profile.phone = phone
            administrator_profile.about = about
            administrator_profile.save()

            messages.success(request, "Administrator updated successfully.")
            return redirect('viewDirectors')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/directors/editDirector.html', {
        'administrator': administrator,
        'form': form,
        'email': email,
        'username': username
    })
    
def deleteDirector(request, id):
    director_profile = get_object_or_404(DirectorProfile, id=id)
    director = get_object_or_404(User, userprofile__director_profile=director_profile)

    user = request.user

    # ✅ Ensure only directors from the same club can delete
    if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
        messages.error(request, "Unauthorized access.")
        return redirect('viewDirectors')

    if user.userprofile.director_profile.club != director_profile.club:
        messages.error(request, "You cannot delete a director from another club.")
        return redirect('viewDirectors')

    director_profile.delete()
    director.delete()

    messages.success(request, "Director deleted successfully.")
    return redirect('viewDirectors')

def viewClubNotifications(request):
    context = {}
    """Displays all club notifications and marks them as read."""
    user = request.user

    # ✅ Ensure the user has a valid director profile
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    # ✅ Fetch all notifications for the club
    notifications = Notification.objects.filter(club=club).order_by('-created_at')

    # ✅ Ensure only unread notifications are marked as read
    unread_count = notifications.filter(is_read=False).update(is_read=True)
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/notifications/viewClubNotifications.html', {
        'notifications': notifications,
        'unread_count': unread_count,  # ✅ Pass unread count for better UI
        'club':club,
    })


def mark_notifications_read(request):
    """Marks all unread notifications as read for the club."""
    user = request.user

    # ✅ Ensure the user has a valid director profile
    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     return JsonResponse({'status': 'error', 'message': 'Unauthorized access'}, status=403)

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    # ✅ Mark only unread notifications as read
    updated_count = Notification.objects.filter(club=club, is_read=False).update(is_read=True)

    return JsonResponse({'status': 'success', 'message': f'Marked {updated_count} notifications as read'})


@login_required
def salon_appointments(request):
    context = {}
    user = request.user
    days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']

    time_slots = []
    for hour in range(1, 13):
        current_time = datetime.strptime(f'{hour:02d}:00:00 AM', '%I:%M:%S %p').time()
        time_slots.append(current_time)
    for hour in range(1, 13):
        current_time = datetime.strptime(f'{hour:02d}:00:00 PM', '%I:%M:%S %p').time()
        time_slots.append(current_time)

    schedule = {}

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    if not club:
        messages.error(request, "No club assigned to your profile. Please contact an administrator.")
        return render(request, 'student/blog/viewArticles.html', {
            'schedule': {},
            'days': days,
            'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots]
        })

    for day in days:
        schedule[day] = []
        appointments = SalonAppointment.objects.filter(
            day=day,
            club=club,
            is_paid=True
        ).order_by('start_time')

        for slot in time_slots:
            slot_end = (datetime.combine(datetime.today(), slot) + timedelta(hours=1)).time()

            slot_appointments = appointments.filter(
                start_time__gte=slot,
                start_time__lt=slot_end
            )

            booking_count = slot_appointments.count()

            slot_info = {
                'time': slot.strftime('%I:%M %p'),
                'booking_count': booking_count,
                'has_bookings': booking_count > 0,
                'appointments': [
                    {
                        'id': appt.id,
                        'start': appt.start_time.strftime('%I:%M %p'),
                        'end': appt.end_time.strftime('%I:%M %p') if appt.end_time else "N/A"
                    } for appt in slot_appointments if hasattr(appt, 'booking')
                ]
            }

            schedule[day].append(slot_info)
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/salon_appointments.html', {
        'schedule': schedule,
        'days': days,
        'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots],
        'club': club,
    })


@login_required
def slot_appointments(request, day, time):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    if not club:
        messages.error(request, "No club assigned to your profile. Please contact an administrator.")
        return redirect('index')

    try:
        if ':' in time:
            hour_str, minute_str = time.split(':')
            hour = int(hour_str)
            minute = int(minute_str.split(' ')[0])
            period = time.split(' ')[1]

            if period == 'PM' and hour < 12:
                hour += 12
            elif period == 'AM' and hour == 12:
                hour = 0

            time_obj = datetime.strptime(f'{hour:02d}:{minute:02d}:00', '%H:%M:%S').time()
            slot_end = (datetime.combine(datetime.today(), time_obj) + timedelta(hours=1)).time()

            # Only get appointments with confirmed payments
            appointments = SalonAppointment.objects.filter(
                day=day,
                club=club,
                is_paid=True,
                start_time__gte=time_obj,
                start_time__lt=slot_end
            ).select_related('booking')

            appointment_details = []
            for appt in appointments:
                if hasattr(appt, 'booking'):
                    booking = appt.booking
                    services = BookingService.objects.filter(booking=booking).select_related('service')
                    service_names = ", ".join([s.service.title for s in services])
                    total_price = sum(s.service.price for s in services)

                    appointment_details.append({
                        'id': appt.id,
                        'services': service_names,
                        'employee': booking.employee,
                        'start_time': appt.start_time.strftime('%I:%M %p'),
                        'end_time': appt.end_time.strftime('%I:%M %p'),
                        'total_price': total_price
                    })

            context = {
                'day': day,
                'time_slot': time,
                'appointments': appointment_details,
                'club':club,
            }
            context['LANGUAGE_CODE'] = translation.get_language()
            return render(request, 'club_dashboard/slot_appointments.html', context)

    except Exception as e:
        messages.error(request, f"Error retrieving appointments: {str(e)}")
        return redirect('club_salon_appointments')

@login_required
def appointment_details(request, appointment_id):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    if not club:
        messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
        return redirect('index')

    appointment = get_object_or_404(SalonAppointment, id=appointment_id)
    if appointment.club != club:
        messages.error(request, "ليس لديك صلاحية لعرض هذا الموعد.")
        return redirect('receptionist_salon_appointments')

    try:
        booking = appointment.booking
        # Explicitly fetch booking services
        booking_services = BookingService.objects.filter(booking=booking).select_related('service')

        if not booking_services.exists():
            messages.warning(request, "لا توجد خدمات مرتبطة بهذا الحجز")

        # For debugging
        print(f"Found {booking_services.count()} services for booking {booking.id}")

        context = {
            'appointment': appointment,
            'booking': booking,
            'employee': booking.employee,
            'booking_services': booking_services,  # Change the variable name to be more explicit
            'total_price': sum(bs.service.price for bs in booking_services),
            'total_duration': sum(bs.service.duration for bs in booking_services),
            'club':club
        }
    except Exception as e:
        messages.error(request, f"لم يتم العثور على معلومات الحجز: {str(e)}")
        return redirect('club_salon_appointments')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/club_appointment_details.html', context)

def reviews_list(request):
    context = {}
    """
    Fetch all reviews for the club associated with the logged-in user.
    """
    # Assuming the logged-in user is a director or admin
    user = request.user

    try:
        # Get the club associated with the logged-in user
        club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


        # Fetch all reviews for coaches in this club
        reviews = Review.objects.filter(coach__club=club).select_related(
            'student', 'coach'
        ).order_by('-created_at')
        # Calculate average rating for the club
        avg_rating = reviews.aggregate(Avg('rating'))['rating__avg'] or 0
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'club_dashboard/reviews_list.html', {
            'reviews': reviews,
            'avg_rating': avg_rating,
            'total_reviews': reviews.count(),
            'club':club
        })

    except AttributeError:
        messages.error(request, "لا يمكن العثور على النادي الخاص بك.")
        return redirect('club_dashboard')


def viewReceptionists(request):
    context = {}
    """Displays a list of coaches belonging to the club."""
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)
    receptionist_userprofile = UserProfile.objects.filter(
        account_type='5',
        receptionist_profile__club=getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    )
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/receptionists/viewReceptionists.html', {'receptionist_userprofile': receptionist_userprofile,'club':club})

@login_required
def addReceptionist(request):
    context = {}
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    # Initialize the correct form
    form = ReceptionistSignupForm(initial={'club': club})

    if request.method == 'POST':
        form = ReceptionistSignupForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']

            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already exists.")
                return redirect('addReceptionist')

            if User.objects.filter(email=email).exists():
                messages.error(request, "Email is already in use.")
                return redirect('addReceptionist')

            receptionist = User.objects.create(username=username, email=email)
            if password:
                receptionist.set_password(password)
            receptionist.save()

            receptionist_profile = ReceptionistProfile.objects.create(
                full_name=form.cleaned_data['full_name'],
                phone=form.cleaned_data['phone'],
                email=email,
                club=form.cleaned_data['club'],  # Get club from form
                about=form.cleaned_data.get('about', "")
            )

            UserProfile.objects.create(user=receptionist, account_type='5', receptionist_profile=receptionist_profile)

            send_notification(user, club, f"📢 A new receptionist {username} has joined {club.name}.")

            messages.success(request, "Receptionist added successfully.")
            return redirect('viewReceptionists')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/receptionists/addReceptionist.html', {'form': form,'club':club})


@login_required
def editReceptionist(request, id):
    context = {}
    """Edits an existing receptionist's details."""
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    receptionist_profile = get_object_or_404(ReceptionistProfile, id=id)
    receptionist = get_object_or_404(User, userprofile__receptionist_profile=receptionist_profile)

    form = ReceptionistProfileForm(instance=receptionist_profile)

    if request.method == 'POST':
        new_username = request.POST.get('username')
        new_email = request.POST.get('email')
        password = request.POST.get('password')

        form = ReceptionistProfileForm(request.POST, instance=receptionist_profile)
        if form.is_valid():
            username_changed = new_username != receptionist.username
            email_changed = new_email != receptionist.email

            receptionist.username = new_username
            receptionist.email = new_email
            if password:
                receptionist.set_password(password)
            receptionist.save()

            form.save()

            notification_message = f"📝 Receptionist {receptionist.username}'s profile was updated."
            if username_changed or email_changed:
                notification_message += " (Username/Email updated.)"

            send_notification(user, club, notification_message)

            messages.success(request, "Receptionist profile updated successfully.")
            return redirect('viewReceptionists')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/receptionists/editReceptionist.html', {
        'form': form,
        'receptionist': receptionist,
        'club':club
    })


@login_required
def deleteReceptionist(request, id):
    """Deletes a receptionist from the club."""
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")
    #     return redirect('home')

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    receptionist_profile = get_object_or_404(ReceptionistProfile, id=id)
    receptionist = get_object_or_404(User, userprofile__receptionist_profile=receptionist_profile)

    receptionist_name = receptionist.username

    receptionist_profile.delete()
    receptionist.delete()

    send_notification(user, club, f"🗑️ Receptionist {receptionist_name} has been removed from the Club.")

    messages.success(request, "Receptionist has been deleted successfully.")
    return redirect('viewReceptionists')

@login_required
def cancel_appointment(request, appointment_id):
    club = get_user_club(request.user)

    if not club:
        messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
        return redirect('index')

    appointment = get_object_or_404(SalonAppointment, id=appointment_id)
    if appointment.club != club:
        messages.error(request, "ليس لديك صلاحية لإلغاء هذا الموعد.")
        return redirect('club_salon_appointments')

    try:
        booking = appointment.booking
        BookingService.objects.filter(booking=booking).delete()
        booking.delete()
        appointment.delete()

        messages.success(request, "تم إلغاء الحجز بنجاح")
    except:
        messages.error(request, "لم يتم العثور على حجز لهذا الموعد")

    return redirect('club_salon_appointments')

@login_required
def club_orders(request):
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     messages.error(request, "Unauthorized access.")

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    orders = Order.objects.filter(club=club).order_by('-created_at')

    status_filter = request.GET.get('status')
    if status_filter and status_filter != 'all':
        orders = orders.filter(status=status_filter)

    from django.db.models import Count, Q, Case, When, IntegerField, Value, CharField

    orders = orders.annotate(
        has_products=Count('items', filter=Q(items__product__isnull=False)),
        has_services=Count('items', filter=Q(items__service__isnull=False))
    ).annotate(
        order_type=Case(
            When(has_products__gt=0, has_services=0, then=Value('products')),
            When(has_products=0, has_services__gt=0, then=Value('services')),
            When(has_products__gt=0, has_services__gt=0, then=Value('mixed')),
            default=Value('unknown'),
            output_field=CharField()
        ),
        order_type_display=Case(
            When(has_products__gt=0, has_services=0, then=Value('منتجات')),
            When(has_products=0, has_services__gt=0, then=Value('خدمات')),
            When(has_products__gt=0, has_services__gt=0, then=Value('منتجات وخدمات')),
            default=Value('غير معروف'),
            output_field=CharField()
        )
    )

    context = {
        'orders': orders,
        'status_filter': status_filter or 'all',
        'club': club,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/orders/club_orders.html', context)

@login_required
def update_order_status(request, order_id):
    user = request.user

    # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
    #     return JsonResponse({'status': 'error', 'message': 'Unauthorized access'}, status=403)

    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    if request.method == 'POST':
        try:
            print(f"Request to update order {order_id} - POST data: {request.POST}")

            order = Order.objects.get(id=order_id, club=club)
            new_status = request.POST.get('status')

            print(f"Current order status: {order.status}, New status: {new_status}")

            if new_status not in dict(Order.STATUS_CHOICES):
                return JsonResponse({'status': 'error', 'message': 'Invalid status'}, status=400)

            old_status = order.status
            order.status = new_status

            try:
                order.full_clean()
            except Exception as validation_error:
                print(f"Validation error: {validation_error}")
                return JsonResponse({'status': 'error', 'message': f'Validation error: {str(validation_error)}'}, status=400)

            try:
                order.save()
                print(f"Order saved successfully with new status: {new_status}")
            except Exception as save_error:
                print(f"Error saving order: {save_error}")
                return JsonResponse({'status': 'error', 'message': f'Database error: {str(save_error)}'}, status=500)

            try:
                has_products = OrderItem.objects.filter(order=order, product__isnull=False).exists()
                has_services = OrderItem.objects.filter(order=order, service__isnull=False).exists()

                order_type = "mixed" if (has_products and has_services) else "products" if has_products else "services"
                print(f"Order type determined: {order_type}")
            except Exception as query_error:
                print(f"Error determining order type: {query_error}")
                order_type = "unknown"

            if new_status == 'confirmed' and old_status == 'pending':
                try:
                    # Process products
                    product_items = OrderItem.objects.filter(order=order, product__isnull=False)
                    for item in product_items:
                        product = item.product
                        product.stock -= item.quantity
                        product.save()
                        print(f"Updated product stock for {product.title}: {product.stock}")

                    # Process services and update appointments
                    service_items = OrderItem.objects.filter(order=order, service__isnull=False)
                    for item in service_items:
                        service = item.service

                        try:
                            # Find the student profile for this user
                            student_profile = None
                            if hasattr(order.user, 'userprofile') and hasattr(order.user.userprofile, 'student_profile'):
                                student_profile = order.user.userprofile.student_profile
                                print(f"Found student profile for user: {student_profile}")

                            if student_profile:
                                bookings = SalonBooking.objects.filter(
                                    student=student_profile
                                ).select_related('appointment')

                                print(f"Found {bookings.count()} bookings for student")

                                booking_services = BookingService.objects.filter(
                                    service=service,
                                    booking__in=bookings
                                )

                                print(f"Found {booking_services.count()} booking services for this service")

                                for booking_service in booking_services:
                                    try:
                                        if booking_service.booking and hasattr(booking_service.booking, 'appointment'):
                                            appointment = booking_service.booking.appointment
                                            if not appointment.is_paid:
                                                appointment.is_paid = True
                                                appointment.save()
                                                print(f"Updated appointment ID {appointment.id} to paid")
                                    except Exception as appt_error:
                                        print(f"Error updating appointment: {str(appt_error)}")

                            service_order = ServiceOrderModel.objects.create(
                                service=service,
                                student=order.user,
                                price=service.price * item.quantity,
                                is_complited=False,
                                end_datetime=timezone.now() + timezone.timedelta(days=service.subscription_days),
                                creation_date=timezone.now()
                            )
                            print(f"Created service order: {service_order.id}")

                        except Exception as service_error:
                            print(f"Error processing service {service.id}: {str(service_error)}")
                            import traceback
                            print(traceback.format_exc())

                except Exception as item_processing_error:
                    print(f"Error processing order items: {str(item_processing_error)}")
                    import traceback
                    print(traceback.format_exc())

            try:
                if new_status == 'confirmed':
                    if order_type == "products":
                        user_notification_message = f"تم تأكيد طلب المنتجات رقم #{order.id} وسيتم تجهيزه قريباً."
                    elif order_type == "services":
                        user_notification_message = f"تم تأكيد طلب الخدمات رقم #{order.id} وسيتم تفعيلها قريباً."
                    else:  # mixed or unknown
                        user_notification_message = f"تم تأكيد طلب المنتجات والخدمات رقم #{order.id} وسيتم معالجته قريباً."
                elif new_status == 'cancelled':
                    if order_type == "products":
                        user_notification_message = f"تم إلغاء طلب المنتجات رقم #{order.id}. يرجى التواصل مع خدمة العملاء للمزيد من المعلومات."
                    elif order_type == "services":
                        user_notification_message = f"تم إلغاء طلب الخدمات رقم #{order.id}. يرجى التواصل مع خدمة العملاء للمزيد من المعلومات."
                    else:  # mixed or unknown
                        user_notification_message = f"تم إلغاء طلب المنتجات والخدمات رقم #{order.id}. يرجى التواصل مع خدمة العملاء للمزيد من المعلومات."
                elif new_status == 'completed':
                    if order_type == "products":
                        user_notification_message = f"تم توصيل منتجاتك من الطلب رقم #{order.id} بنجاح. شكراً لك!"
                    elif order_type == "services":
                        user_notification_message = f"تم تفعيل خدماتك من الطلب رقم #{order.id} بنجاح. شكراً لك!"
                    else:  # mixed or unknown
                        user_notification_message = f"تم اكتمال طلب المنتجات والخدمات رقم #{order.id} بنجاح. شكراً لك!"
                else:
                    user_notification_message = f"تم تحديث حالة الطلب رقم #{order.id} إلى {dict(Order.STATUS_CHOICES)[new_status]}."

                try:
                    Notification.objects.create(
                        user=order.user,
                        message=user_notification_message,
                        notification_type='order_update'
                    )
                    print(f"Created notification for user {order.user.id}")
                except Exception as notification_error:
                    print(f"Error creating notification: {notification_error}")
            except Exception as message_error:
                print(f"Error creating notification message: {message_error}")

            return JsonResponse({
                'status': 'success',
                'message': f'تم تحديث حالة الطلب إلى {dict(Order.STATUS_CHOICES)[new_status]}'
            })

        except Order.DoesNotExist:
            print(f"Order {order_id} not found")
            return JsonResponse({'status': 'error', 'message': 'Order not found'}, status=404)
        except Exception as e:
            print(f"Unexpected error in update_order_status: {str(e)}")
            return JsonResponse({'status': 'error', 'message': f'Server error: {str(e)}'}, status=500)

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=400)

@login_required
def order_details_api(request, order_id):
    user = request.user
    print(f"طلب تفاصيل الطلب {order_id} بواسطة {user}")

    try:
        # if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
        #     print("غير مصرح به")
        #     return JsonResponse({'status': 'error', 'message': 'Unauthorized access'}, status=403)

        club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


        order = Order.objects.get(id=order_id, club=club)
        order_items = OrderItem.objects.filter(order=order)

        context = {
            'order': order,
            'order_items': order_items,
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        html = render_to_string('club_dashboard/orders/order_details_modal.html', context)

        return JsonResponse({
            'status': 'success',
            'html': html
        })
    except Order.DoesNotExist:
        print(f"الطلب {order_id} غير موجود")
        return JsonResponse({'status': 'error', 'message': 'Order not found'}, status=404)
    except Exception as e:
        print(f"خطأ غير متوقع: {str(e)}")
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


def add_shipment(request):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    if request.method == 'POST':
        form = ProductShipmentForm(request.POST, club=club)
        if form.is_valid():
            shipment = form.save()

            product = shipment.product
            product.stock += shipment.quantity

            if shipment.manufacturing_date and not product.manufacturing_date:
                product.manufacturing_date = shipment.manufacturing_date

            if shipment.expiration_date:
                if not product.expiration_date or shipment.expiration_date > product.expiration_date:
                    product.expiration_date = shipment.expiration_date

            product.save()

            messages.success(request, 'تم إضافة الشحنة بنجاح!')
            return redirect('view_product_shipments', product_id=shipment.product.id)
    else:
        form = ProductShipmentForm(club=club)

    product_id = request.GET.get('product_id')
    if product_id:
        try:
            product = ProductsModel.objects.get(id=product_id, club=club)
            form.initial['product'] = product
        except ProductsModel.DoesNotExist:
            pass

    context = {
        'form': form,
        'club':club
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/products/ProductsStock/add_shipment.html', context)

def view_product_shipments(request, product_id):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)


    try:
        product = ProductsModel.objects.get(id=product_id, club=club)
    except ProductsModel.DoesNotExist:
        messages.error(request, 'المنتج غير موجود!')
        return redirect('viewProducts')

    shipments = ProductShipment.objects.filter(product=product).order_by('-created_at')

    expiring_soon_count = sum(1 for s in shipments if s.is_expiring_soon)
    expired_count = sum(1 for s in shipments if s.is_expired)
    valid_count = len(shipments) - expiring_soon_count - expired_count

    total_quantity = sum(s.quantity for s in shipments)
    expiring_soon_quantity = sum(s.quantity for s in shipments if s.is_expiring_soon)
    expired_quantity = sum(s.quantity for s in shipments if s.is_expired)
    valid_quantity = total_quantity - expiring_soon_quantity - expired_quantity

    context = {
        'product': product,
        'shipments': shipments,
        'stats': {
            'total_count': len(shipments),
            'expiring_soon_count': expiring_soon_count,
            'expired_count': expired_count,
            'valid_count': valid_count,
            'total_quantity': total_quantity,
            'expiring_soon_quantity': expiring_soon_quantity,
            'expired_quantity': expired_quantity,
            'valid_quantity': valid_quantity,
        },
        'club':club,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/products/ProductsStock/view_product_shipments.html', context)

def product_details(request, product_id):
    user = request.user
    club = getattr(user.userprofile.director_profile, 'club', None) or getattr(user.userprofile.administrator_profile, 'club', None)

    try:
        product = ProductsModel.objects.get(id=product_id, club=club)
    except ProductsModel.DoesNotExist:
        messages.error(request, 'المنتج غير موجود!')
        return redirect('viewProducts')

    product_images = product.product_images.all()

    shipments = ProductShipment.objects.filter(product=product).order_by('-created_at')

    expiring_soon_count = sum(1 for s in shipments if s.is_expiring_soon)
    expired_count = sum(1 for s in shipments if s.is_expired)
    valid_count = len(shipments) - expiring_soon_count - expired_count

    total_quantity = sum(s.quantity for s in shipments)
    expiring_soon_quantity = sum(s.quantity for s in shipments if s.is_expiring_soon)
    expired_quantity = sum(s.quantity for s in shipments if s.is_expired)
    valid_quantity = total_quantity - expiring_soon_quantity - expired_quantity

    context = {
        'product': product,
        'product_images': product_images,
        'shipments': shipments,
        'stats': {
            'total_count': len(shipments),
            'expiring_soon_count': expiring_soon_count,
            'expired_count': expired_count,
            'valid_count': valid_count,
            'total_quantity': total_quantity,
            'expiring_soon_quantity': expiring_soon_quantity,
            'expired_quantity': expired_quantity,
            'valid_quantity': valid_quantity,
        },
        'club':club,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/products/ProductsStock/product_details.html', context)


@login_required
def club_financial_dashboard(request):
    user = request.user

    if not hasattr(user.userprofile, 'director_profile') or not user.userprofile.director_profile:
        messages.error(request, "Unauthorized access.")
        return redirect('home')

    club = user.userprofile.director_profile.club

    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if not start_date:
        start_date = (timezone.now() - timezone.timedelta(days=30)).strftime('%Y-%m-%d')
    if not end_date:
        end_date = timezone.now().strftime('%Y-%m-%d')

    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
        end_date_obj = end_date_obj.replace(hour=23, minute=59, second=59)
    except ValueError:
        start_date_obj = timezone.now() - timezone.timedelta(days=30)
        end_date_obj = timezone.now()

    orders = Order.objects.filter(
        club=club,
        created_at__gte=start_date_obj,
        created_at__lte=end_date_obj
    ).order_by('-created_at')

    credit_card_orders = orders.filter(payment_method='credit_card')
    cash_orders = orders.filter(payment_method='cash_on_delivery')

    total_revenue = orders.filter(status__in=['confirmed', 'completed']).aggregate(Sum('total_price'))['total_price__sum'] or 0
    pending_revenue = orders.filter(status='pending').aggregate(Sum('total_price'))['total_price__sum'] or 0

    credit_card_revenue = credit_card_orders.filter(status__in=['confirmed', 'completed']).aggregate(Sum('total_price'))['total_price__sum'] or 0
    cash_revenue = cash_orders.filter(status__in=['confirmed', 'completed']).aggregate(Sum('total_price'))['total_price__sum'] or 0

    total_confirmed_revenue = total_revenue
    credit_card_percentage = 0
    cash_percentage = 0
    if total_confirmed_revenue > 0:
        credit_card_percentage = round((credit_card_revenue / total_confirmed_revenue) * 100)
        cash_percentage = round((cash_revenue / total_confirmed_revenue) * 100)

    months_data = []
    for i in range(6):
        month_date = timezone.now() - timezone.timedelta(days=30 * i)
        month_start = month_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if month_date.month == 12:
            month_end = month_date.replace(year=month_date.year + 1, month=1, day=1, hour=0, minute=0, second=0, microsecond=0) - timezone.timedelta(seconds=1)
        else:
            month_end = month_date.replace(month=month_date.month + 1, day=1, hour=0, minute=0, second=0, microsecond=0) - timezone.timedelta(seconds=1)

        month_orders = Order.objects.filter(
            club=club,
            created_at__gte=month_start,
            created_at__lte=month_end,
            status__in=['confirmed', 'completed']
        )

        month_credit = month_orders.filter(payment_method='credit_card').aggregate(Sum('total_price'))['total_price__sum'] or 0
        month_cash = month_orders.filter(payment_method='cash_on_delivery').aggregate(Sum('total_price'))['total_price__sum'] or 0

        months_data.append({
            'month': month_start.strftime('%B %Y'),
            'credit_card': float(month_credit),
            'cash': float(month_cash),
            'total': float(month_credit + month_cash)
        })

    months_data.reverse()

    order_items = OrderItem.objects.filter(order__club=club, order__status__in=['confirmed', 'completed'])

    product_sales = {}
    service_sales = {}

    for item in order_items:
        if item.product:
            product_id = item.product.id
            product_name = item.product.title
            if product_id in product_sales:
                product_sales[product_id]['quantity'] += item.quantity
                product_sales[product_id]['revenue'] += float(item.price * item.quantity)
            else:
                product_sales[product_id] = {
                    'name': product_name,
                    'quantity': item.quantity,
                    'revenue': float(item.price * item.quantity)
                }

        if item.service:
            service_id = item.service.id
            service_name = item.service.title
            if service_id in service_sales:
                service_sales[service_id]['quantity'] += item.quantity
                service_sales[service_id]['revenue'] += float(item.price * item.quantity)
            else:
                service_sales[service_id] = {
                    'name': service_name,
                    'quantity': item.quantity,
                    'revenue': float(item.price * item.quantity)
                }

    top_products = sorted([v for k, v in product_sales.items()], key=lambda x: x['revenue'], reverse=True)[:5]
    top_services = sorted([v for k, v in service_sales.items()], key=lambda x: x['revenue'], reverse=True)[:5]

    context = {
        'all_orders': orders,
        'orders': orders,
        'credit_card_orders': credit_card_orders,
        'cash_orders': cash_orders,
        'total_revenue': total_revenue,
        'pending_revenue': pending_revenue,
        'credit_card_revenue': credit_card_revenue,
        'cash_revenue': cash_revenue,
        'credit_card_percentage': credit_card_percentage,
        'cash_percentage': cash_percentage,
        'start_date': start_date,
        'end_date': end_date,
        'months_data': json.dumps(months_data),
        'top_products': top_products,
        'top_services': top_services,
    }
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'club_dashboard/financial/dashboard.html', context)

@login_required
def view_director_profile(request):
    """View the director's profile"""
    try:
        # Get the current user's UserProfile
        userprofile = request.user.userprofile

        # Check if user is a director
        if not userprofile.director_profile:
            return HttpResponseForbidden("You don't have permission to view this page")

        director = userprofile.director_profile

        context = {
            'director': director,
            'userprofile': userprofile,
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'accounts/profiles/Director/ViewDirectorProfile.html', context)
    except UserProfile.DoesNotExist:
        return HttpResponseForbidden("User profile not found")

@login_required
def edit_director_profile(request):
    """Edit the director's profile"""
    try:
        # Get the current user's UserProfile
        userprofile = request.user.userprofile

        # Check if user is a director
        if not userprofile.director_profile:
            return HttpResponseForbidden("You don't have permission to edit this page")

        director = userprofile.director_profile

        if request.method == 'POST':
            form = DirectorProfileForm(request.POST, request.FILES, instance=director)
            if form.is_valid():
                # Save director profile form
                director = form.save()

                # Handle profile image upload
                if 'profile_image_base64' in request.FILES:
                    image_file = request.FILES['profile_image_base64']
                    # Convert the image to base64
                    encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
                    image_data = f"data:image/{image_file.content_type.split('/')[-1]};base64,{encoded_image}"

                    # Update the user profile
                    userprofile.profile_image_base64 = image_data
                    userprofile.save()

                return redirect(reverse('view_director_profile'))
        else:
            form = DirectorProfileForm(instance=director)

        context = {
            'form': form,
            'director': director,
            'userprofile': userprofile,
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'accounts/settings/Director/EditDirectorProfile.html', context)
    except UserProfile.DoesNotExist:
        return HttpResponseForbidden("User profile not found")

def handle_uploaded_image(image_file):
    """Convert uploaded image to base64 string"""
    if not image_file:
        return None

    # Check file size (limit to 2MB)
    if image_file.size > 2 * 1024 * 1024:
        raise ValueError("Image file too large (max 2MB)")

    # Get file extension
    file_extension = image_file.name.split('.')[-1].lower()
    if file_extension not in ['jpg', 'jpeg', 'png', 'gif']:
        raise ValueError("Unsupported file format")

    # Convert to base64
    encoded_image = base64.b64encode(image_file.read()).decode('utf-8')

    # Create data URL based on file type
    if file_extension in ['jpg', 'jpeg']:
        return f"data:image/jpeg;base64,{encoded_image}"
    elif file_extension == 'png':
        return f"data:image/png;base64,{encoded_image}"
    elif file_extension == 'gif':
        return f"data:image/gif;base64,{encoded_image}"


