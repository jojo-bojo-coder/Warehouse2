from django.shortcuts import render, redirect,get_object_or_404
from .forms import CoachAppointmentsForm, StudentAppointmentPresenceForm
from .models import CoachAppointmentsModel, StudentAppointmentPresenceModel
import datetime, json
from students.models import ServiceOrderModel, ServicesModel,Order,OrderItem
from django.contrib.auth.models import User
from django.http import JsonResponse
from accounts.models import UserProfile,StudentProfile
from django.utils import timezone
import datetime  # ✅ Import datetime module
from club_dashboard.models import Notification
from .utils import send_notification
from django.contrib.auth.decorators import login_required  # ✅ Fix missing import
from django.contrib import messages
from club_dashboard.models import SalonAppointment
from datetime import datetime,timedelta
from receptionist_dashboard.models import BookingService,SalonBooking
import base64
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import CoachProfile
from .forms import CoachProfileForm
from django.utils import translation
from django.utils.translation import get_language
from django.forms import formset_factory
from receptionist_dashboard.forms import SalonBookingForm ,ServiceSelectionForm
from django.db import models, transaction
from students.models import ProductsModel , CartItem,ServiceCartItem,OrderItem,Order
# Create your views here.

def get_user_club(user):
    user_profile = user.userprofile
    club = None
    if user_profile.account_type == '3':  # Student
        club = user_profile.student_profile.club if hasattr(user_profile, 'student_profile') else None
    elif user_profile.account_type == '4':  # Coach
        club = user_profile.Coach_profile.club if hasattr(user_profile, 'Coach_profile') else None
    elif user_profile.account_type == '2':  # Director
        club = user_profile.director_profile.club if hasattr(user_profile, 'director_profile') else None
    elif user_profile.account_type == '5':  # Receptionist
        club = user_profile.receptionist_profile.club if hasattr(user_profile, 'receptionist_profile') else None
    return club

def index(request):
    context = {}
    user = request.user

    # Verify coach access
    if not hasattr(user, 'userprofile') or not hasattr(user.userprofile, 'Coach_profile') or not user.userprofile.Coach_profile:
        messages.error(request, "ليس لديك صلاحية للوصول إلى هذه الصفحة.")
        return redirect('home')  # Redirect to appropriate page

    coach = user.userprofile.Coach_profile
    coach_identifier = coach.full_name

    # Get language for messages
    lang = translation.get_language()

    try:
        # First, find all orders with status 'confirmed' that have services associated with this coach
        confirmed_orders = Order.objects.filter(status='confirmed')

        # Find all order items with services from these confirmed orders
        confirmed_order_items = OrderItem.objects.filter(
            order__in=confirmed_orders,
            service__isnull=False  # Only service items, not product items
        )

        # Get the service IDs from these confirmed order items
        confirmed_service_ids = confirmed_order_items.values_list('service_id', flat=True)

        # Find all bookings for this coach that have the confirmed services
        salon_bookings = SalonBooking.objects.filter(
            employee=coach_identifier,
            services__service_id__in=confirmed_service_ids
        ).distinct()

        # Collect all appointments from these bookings
        confirmed_appointments = []

        for booking in salon_bookings:
            # Check if this booking has appointments
            appointments = []

            if hasattr(booking, 'appointments'):
                # Many-to-one relationship with name 'appointments'
                appointments = booking.appointments.all()
            elif hasattr(booking, 'appointment'):
                if hasattr(booking.appointment, 'all'):
                    # Many-to-one relationship with name 'appointment'
                    appointments = booking.appointment.all()
                else:
                    # One-to-one relationship
                    appointments = [booking.appointment]
            elif hasattr(booking, 'coachappointment_set'):
                # Reverse relation using Django's default naming
                appointments = booking.coachappointment_set.all()

            # Add any found appointments to our list
            confirmed_appointments.extend(appointments)

        # Sort the appointments by creation date (newest first) and get the last 4
        # Assuming there's a 'created_at' field - adjust if your model uses a different field name
        confirmed_appointments.sort(key=lambda x: x.created_at if hasattr(x, 'created_at') else x.id, reverse=True)
        last_four_appointments = confirmed_appointments[:4]

    except Exception as e:
        print(f"Error retrieving appointments: {str(e)}")
        last_four_appointments = []

    club = coach.club if coach and hasattr(coach, 'club') else None
    context['LANGUAGE_CODE'] = lang
    context['CoachAppointments'] = last_four_appointments
    context['coachName'] = coach_identifier

    return render(request, 'coach_dashboard/index.html', context)


def viewCoachAppointments(request):
    context = {}
    user = request.user

    if not hasattr(user, 'userprofile') or not hasattr(user.userprofile, 'Coach_profile') or not user.userprofile.Coach_profile:
        messages.error(request, "ليس لديك صلاحية للوصول إلى هذه الصفحة.")
        return redirect('coachIndex')

    coach = user.userprofile.Coach_profile
    coach_identifier = coach.full_name


    lang = translation.get_language()

    try:
        confirmed_orders = Order.objects.filter(status='confirmed')

        confirmed_order_items = OrderItem.objects.filter(
            order__in=confirmed_orders,
            service__isnull=False
        )

        confirmed_service_ids = confirmed_order_items.values_list('service_id', flat=True)

        salon_bookings = SalonBooking.objects.filter(
            employee=coach_identifier,
            services__service_id__in=confirmed_service_ids
        ).distinct()

        confirmed_appointments = []

        for booking in salon_bookings:
            appointments = []

            if hasattr(booking, 'appointments'):
                appointments = booking.appointments.all()
            elif hasattr(booking, 'appointment'):
                if hasattr(booking.appointment, 'all'):
                    appointments = booking.appointment.all()
                else:
                    appointments = [booking.appointment]
            elif hasattr(booking, 'coachappointment_set'):
                appointments = booking.coachappointment_set.all()

            confirmed_appointments.extend(appointments)

        print(f"Found {len(confirmed_appointments)} confirmed appointments for coach {coach_identifier}")

        if confirmed_appointments:
            message = "عرض المواعيد المؤكدة فقط" if lang == 'ar' else "Showing confirmed appointments only"
        else:
            message = f"لا توجد مواعيد مؤكدة ({len(salon_bookings)} حجوزات)" if lang == 'ar' else f"No confirmed appointments found ({len(salon_bookings)} bookings)"
            print(f"Debug: Confirmed service IDs: {list(confirmed_service_ids)}")
            print(f"Debug: Coach bookings count: {salon_bookings.count()}")

    except Exception as e:
        print(f"Error retrieving appointments: {str(e)}")
        confirmed_appointments = []
        message = f"خطأ في استرجاع المواعيد: {str(e)}" if lang == 'ar' else f"Error retrieving appointments: {str(e)}"

    messages.info(request, message)

    context['LANGUAGE_CODE'] = lang
    context['CoachAppointments'] = confirmed_appointments
    context['filter_type'] = 'confirmed'
    return render(request, 'coach_dashboard/CoachAppointments/viewCoachAppointments.html', context)


def addCoachAppointments(request):
    user = request.user

    if not hasattr(user.userprofile, 'Coach_profile') or not user.userprofile.Coach_profile:
        messages.error(request, "ليس لديك صلاحية للوصول إلى هذه الصفحة.")
        return redirect('coachIndex')

    coach = user.userprofile.Coach_profile
    club = coach.club

    club_services = ServicesModel.objects.filter(club=club)
    form = CoachAppointmentsForm(coach=coach)

    if request.method == 'POST':
        form = CoachAppointmentsForm(request.POST, coach=coach)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.coach = coach
            appointment.end_datetime = appointment.start_datetime + datetime.timedelta(days=1)
            appointment.save()

            send_notification(user, club, f"📅 تمت إضافة موعد جديد بواسطة المدرب {coach.full_name} في {appointment.start_datetime.strftime('%Y-%m-%d %H:%M')}.")
            messages.success(request, "تمت إضافة الموعد بنجاح.")
            return redirect('viewCoachAppointments')

    return render(request, 'coach_dashboard/CoachAppointments/addCoachAppointments.html', {
        'form': form,
        'club_services': club_services
    })


def editCoachAppointments(request, id):
    user = request.user

    if not hasattr(user.userprofile, 'Coach_profile') or not user.userprofile.Coach_profile:
        messages.error(request, "ليس لديك صلاحية للوصول إلى هذه الصفحة.")
        return redirect('coachIndex')

    coach = user.userprofile.Coach_profile
    club = coach.club

    coach_appointment = get_object_or_404(CoachAppointmentsModel, id=id, coach=coach)

    form = CoachAppointmentsForm(instance=coach_appointment, coach=coach)

    if request.method == 'POST':
        form = CoachAppointmentsForm(request.POST, instance=coach_appointment, coach=coach)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.end_datetime = appointment.start_datetime + datetime.timedelta(days=1)
            appointment.save()

            send_notification(user, club, f"📝 تم تعديل موعد بواسطة المدرب {coach.full_name}. الموعد الجديد: {appointment.start_datetime.strftime('%Y-%m-%d %H:%M')}.")
            messages.success(request, "تم تعديل الموعد بنجاح.")
            return redirect('viewCoachAppointments')

    return render(request, 'coach_dashboard/CoachAppointments/editCoachAppointments.html', {'form': form})


def deleteCoachAppointments(request, id):
    user = request.user

    if not hasattr(user.userprofile, 'Coach_profile') or not user.userprofile.Coach_profile:
        messages.error(request, "ليس لديك صلاحية للوصول إلى هذه الصفحة.")
        return redirect('coachIndex')

    coach = user.userprofile.Coach_profile
    club = coach.club

    coach_appointment = get_object_or_404(CoachAppointmentsModel, id=id, coach=coach)
    appointment_time = coach_appointment.start_datetime.strftime('%Y-%m-%d %H:%M')

    coach_appointment.delete()

    send_notification(user, club, f"🗑️ تم حذف الموعد بتاريخ {appointment_time} بواسطة المدرب {coach.full_name}.")
    messages.success(request, "تم حذف الموعد بنجاح.")
    return redirect('viewCoachAppointments')




#StudentAppointmentPresences
# def viewStudentAppointmentPresences(request):
#     coach = request.user
#     coach_profile = coach.userprofile.Coach_profile
#     club = coach_profile.club
#     services = ServicesModel.objects.filter(club=club)
#     StudentAppointmentPresences = StudentAppointmentPresenceModel.objects.filter(appointment__coach=coach_profile)
#
#     coach = request.user.userprofile.Coach_profile
#     form = StudentAppointmentPresenceForm(coach=coach)
#
#     return render(request, 'coach_dashboard/StudentAppointmentPresences/viewStudentAppointmentPresences.html', {'StudentAppointmentPresences':StudentAppointmentPresences, 'services':services, 'form':form})
#
# def addStudentAppointmentPresence(request):
#     coach = request.user.userprofile.Coach_profile
#     form = StudentAppointmentPresenceForm(coach=coach)
#
#     if request.method == 'POST':
#         form = StudentAppointmentPresenceForm(request.POST, coach=coach)
#         student_id = request.POST.get('student_id')
#         student_profile = UserProfile.objects.get(user__id=student_id).student_profile
#         if form.is_valid():
#             presence = form.save(commit=False)
#             presence.student = student_profile
#             presence.creation_date = timezone.now()
#             presence.save()
#             return redirect('viewStudentAppointmentPresences')
#     return render(request, 'coach_dashboard/StudentAppointmentPresences/addStudentAppointmentPresence.html', {'form':form})
#
#
# def editStudentAppointmentPresence(request, id):
#     coach = request.user.userprofile.Coach_profile
#     CoachAppointment = StudentAppointmentPresenceModel.objects.get(id=id)
#     form = StudentAppointmentPresenceForm(instance=CoachAppointment, coach=coach)
#     if request.method == 'POST':
#         form = StudentAppointmentPresenceForm(request.POST, instance=CoachAppointment, coach=coach)
#         if form.is_valid():
#             form.save()
#     return render(request, 'coach_dashboard/StudentAppointmentPresences/editStudentAppointmentPresence.html', {'form':form})
#
# def deleteStudentAppointmentPresence(request, id):
#     StudentAppointmentPresence = StudentAppointmentPresenceModel.objects.get(id=id)
#     StudentAppointmentPresence.delete()
#     return redirect('viewStudentAppointmentPresences')



def getServiceStudents(request, service_id):
    coach = request.user
    coach_profile = coach.userprofile.Coach_profile
    club = coach_profile.club
    students = User.objects.filter(userprofile__account_type='3', userprofile__student_profile__club=club)
    students_list = []
    service = ServicesModel.objects.get(id=service_id)
    for student in students:
        services_order = ServiceOrderModel.objects.filter(service=service, student=student)
        if services_order.exists():
            students_list.append({'full_name':student.userprofile.student_profile.full_name, 'user_id':student.id})
    
    return JsonResponse(students_list, safe=False)

@login_required
def salon_appointments(request):
    context = {}

    days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']

    time_slots = []
    for hour in range(1, 13):
        current_time = datetime.strptime(f'{hour:02d}:00:00 AM', '%I:%M:%S %p').time()
        time_slots.append(current_time)
    for hour in range(1, 13):
        current_time = datetime.strptime(f'{hour:02d}:00:00 PM', '%I:%M:%S %p').time()
        time_slots.append(current_time)


    schedule = {}

    club = get_user_club(request.user)
    if not club:
        messages.error(request, "No club assigned to your profile. Please contact an administrator.")
        return render(request, 'coach_dashboard/salon_appointments.html', {
            'schedule': {},
            'days': days,
            'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots]
        })

    for day in days:
        schedule[day] = []
        appointments = SalonAppointment.objects.filter(
            day=day,
            club=club,
            is_paid=True
        ).order_by('start_time')

        for slot in time_slots:
            slot_end = (datetime.combine(datetime.today(), slot) + timedelta(hours=1)).time()

            slot_appointments = appointments.filter(
                start_time__gte=slot,
                start_time__lt=slot_end
            )

            booking_count = slot_appointments.count()

            slot_info = {
                'time': slot.strftime('%I:%M %p'),
                'booking_count': booking_count,
                'has_bookings': booking_count > 0,
                'appointments': [
                    {
                        'id': appt.id,
                        'start': appt.start_time.strftime('%I:%M %p'),
                        'end': appt.end_time.strftime('%I:%M %p') if appt.end_time else "N/A"
                    } for appt in slot_appointments if hasattr(appt, 'booking')
                ]
            }

            schedule[day].append(slot_info)
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'coach_dashboard/salon_appointments.html', {
        'schedule': schedule,
        'days': days,
        'time_slots': [slot.strftime('%I:%M %p') for slot in time_slots],
        'club': club,
    })

@login_required
def slot_appointments(request, day, time):
    club = get_user_club(request.user)
    if not club:
        messages.error(request, "No club assigned to your profile. Please contact an administrator.")
        return redirect('index')

    try:
        if ':' in time:
            hour_str, minute_str = time.split(':')
            hour = int(hour_str)
            minute = int(minute_str.split(' ')[0])
            period = time.split(' ')[1]

            if period == 'PM' and hour < 12:
                hour += 12
            elif period == 'AM' and hour == 12:
                hour = 0

            time_obj = datetime.strptime(f'{hour:02d}:{minute:02d}:00', '%H:%M:%S').time()
            slot_end = (datetime.combine(datetime.today(), time_obj) + timedelta(hours=1)).time()

            # Get all appointments in this time slot
            appointments = SalonAppointment.objects.filter(
                day=day,
                club=club,
                is_paid=True,
                start_time__gte=time_obj,
                start_time__lt=slot_end
            ).select_related('booking')

            appointment_details = []
            for appt in appointments:
                if hasattr(appt, 'booking'):
                    booking = appt.booking
                    services = BookingService.objects.filter(booking=booking).select_related('service')
                    service_names = ", ".join([s.service.title for s in services])
                    total_price = sum(s.service.price for s in services)

                    appointment_details.append({
                        'id': appt.id,
                        'services': service_names,
                        'employee': booking.employee,
                        'start_time': appt.start_time.strftime('%I:%M %p'),
                        'end_time': appt.end_time.strftime('%I:%M %p'),
                        'total_price': total_price
                    })

            context = {
                'day': day,
                'time_slot': time,
                'appointments': appointment_details
            }
            context['LANGUAGE_CODE'] = translation.get_language()
            return render(request, 'coach_dashboard/slot_appointments.html', context)

    except Exception as e:
        messages.error(request, f"Error retrieving appointments: {str(e)}")
        return redirect('receptionist_salon_appointments')

@login_required
def select_appointment_day(request):
    context = {}
    club = get_user_club(request.user)
    if not club:
        messages.error(request, "No club assigned to your profile. Please contact an administrator.")
        return redirect('coachIndex')

    days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']


    if request.method == 'POST':
        selected_day = request.POST.get('day')
        return redirect('coach_book_appointment_details', day=selected_day)
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'coach_dashboard/select_appointment_day.html', {
        'days': days
    })

@login_required
def book_appointment_details(request, day):
    context = {}
    club = get_user_club(request.user)
    # if not club:
    #     messages.error(request, "No club assigned to your profile. Please contact an administrator.")
    #     return redirect('coachIndex')
    #
    # try:
    coach_profile = request.user.userprofile.Coach_profile
    # except AttributeError:
    #     messages.error(request, "You must be a coach to book appointments for students.")
    #     return redirect('coachIndex')

    # Get available services for which this coach is associated
    available_services = ServicesModel.objects.filter(
        club=club,
        is_enabled=True,
        coaches=coach_profile
    )

    # if not available_services.exists():
    #     messages.error(request, "No services are associated with your profile. Please contact an administrator.")
    #     return redirect('coachIndex')

    ServiceFormSet = formset_factory(ServiceSelectionForm, extra=1)

    # Get all students in this club - FIXED QUERY
    club_students = StudentProfile.objects.filter(club=club)

    # Get existing appointments for the day
    appointments = []
    day_appointments = SalonAppointment.objects.filter(
        day=day,
        available=False,
        club=club,
    ).order_by('start_time')

    for appointment in day_appointments:
        try:
            booking = appointment.booking
            services = BookingService.objects.filter(booking=booking)
            service_names = ", ".join([s.service.title for s in services])

            start_datetime = datetime.datetime.combine(datetime.datetime.today(), appointment.start_time)
            end_datetime = datetime.datetime.combine(datetime.datetime.today(), appointment.end_time)
            total_duration = (end_datetime - start_datetime).seconds / 60

            appointments.append({
                'start_time': appointment.start_time,
                'end_time': appointment.end_time,
                'employee_name': booking.employee,
                'total_duration': total_duration,
                'services': service_names
            })
        except:
            # Skip appointments without valid booking information
            continue

    if request.method == 'POST':
        booking_form = SalonBookingForm(request.POST)
        service_formset = ServiceFormSet(request.POST, prefix='services')

        if booking_form.is_valid() and service_formset.is_valid():
            # Calculate total duration
            total_duration = 0
            services_data = []

            for form in service_formset:
                if form.cleaned_data and form.cleaned_data.get('service'):
                    service = form.cleaned_data['service']
                    total_duration += service.duration
                    services_data.append({
                        'service_id': service.id,
                        'coach_id': coach_profile.id,
                        'coach_name': coach_profile.full_name
                    })

            # Create booking data for session
            booking_data = booking_form.cleaned_data.copy()

            # Add the coach (logged-in user) as the employee
            booking_data['employee_id'] = coach_profile.id
            booking_data['employee_name'] = coach_profile.full_name


            request.session['booking_form_data'] = booking_data
            request.session['services_data'] = services_data
            request.session['total_duration'] = total_duration

            return redirect('coach_select_appointment_time', day=day)
        else:
            messages.error(request, "هناك خطأ في البيانات المدخلة. الرجاء التحقق والمحاولة مرة أخرى.")
            print(f"Form errors: {booking_form.errors}")
            print(f"Formset errors: {service_formset.errors}")
    else:
        # Initialize the form with the coach's students
        booking_form = SalonBookingForm()

        service_formset = ServiceFormSet(prefix='services')
        for form in service_formset:
            # Only show services this coach is associated with
            form.fields['service'].queryset = available_services
            # Remove the coach field as it will always be the logged-in coach
            if 'coach' in form.fields:
                form.fields.pop('coach')

    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'coach_dashboard/book_appointment_details.html', {
        'booking_form': booking_form,
        'service_formset': service_formset,
        'day': day,
        'appointments': appointments,
        'current_user': request.user,
        'club': club,
        'available_services': available_services,
        'coach_profile': coach_profile,
    })

@login_required
def get_service_info(request, service_id):
    """
    Returns JSON with service information including duration and associated coaches
    """
    try:
        service = ServicesModel.objects.get(id=service_id)
        coaches = service.coaches.all()

        coach_data = [
            {
                'id': coach.id,
                'name': coach.full_name
            } for coach in coaches
        ]

        return JsonResponse({
            'duration': service.duration,
            'coaches': coach_data
        })
    except ServicesModel.DoesNotExist:
        return JsonResponse({'error': 'Service not found'}, status=404)

@login_required
def select_appointment_time(request, day):
    context = {}
    club = get_user_club(request.user)
    # if not club:
    #     messages.error(request, "No club assigned to your profile. Please contact an administrator.")
    #     return redirect('coachIndex')

    # Check if logged-in user is a coach
    #try:
    coach_profile = request.user.userprofile.Coach_profile
    # except AttributeError:
    #     messages.error(request, "You must be a coach to book appointments for students.")
    #     return redirect('coachIndex')

    booking_form_data = request.session.get('booking_form_data', {})
    coach_id = coach_profile.id
    coach_name = coach_profile.full_name

    time_slots = []
    for hour in range(1, 13):
        time = datetime.strptime(f'{hour:02d}:00:00 AM', '%I:%M:%S %p').time()
        time_slots.append(time)
    for hour in range(1, 13):
        time = datetime.strptime(f'{hour:02d}:00:00 PM', '%I:%M:%S %p').time()
        time_slots.append(time)

    total_duration = request.session.get('total_duration', 0)

    available_slots = []
    for i, slot in enumerate(time_slots):
        slot_dict = {
            'time': slot.strftime('%I:%M %p'),
            'available': True,
            'coach_booked': False
        }
        available_slots.append(slot_dict)

    # Check coach availability for each slot
    for i, slot in enumerate(available_slots):
        time_str = slot['time']
        time_parts = time_str.split()
        period = time_parts[1]
        hours, minutes = time_parts[0].split(':')
        hours = int(hours)
        minutes = int(minutes)

        if period == 'PM' and hours < 12:
            hours += 12
        elif period == 'AM' and hours == 12:
            hours = 0

        slot_time = datetime.strptime(f'{hours:02d}:{minutes:02d}:00', '%H:%M:%S').time()
        slot_end_time = (datetime.combine(datetime.today(), slot_time) + timedelta(minutes=total_duration)).time()

        # Check coach availability
        coach_conflicts = check_coach_availability(day, slot_time, slot_end_time, coach_id, club)
        if coach_conflicts:
            available_slots[i]['available'] = False
            available_slots[i]['coach_booked'] = True

    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'coach_dashboard/select_appointment_time.html', {
        'day': day,
        'time_slots': available_slots,
        'total_duration': total_duration,
        'coach_name': coach_name
    })



def check_coach_availability(day, start_time, end_time, coach_id, club):
    """
    Check if a coach is available at the given time slot
    Returns conflicting appointments if any
    """
    from accounts.models import CoachProfile

    try:
        coach = CoachProfile.objects.get(id=coach_id)
        coach_name = coach.full_name
    except CoachProfile.DoesNotExist:
        return False

    conflicts = SalonAppointment.objects.filter(
        day=day,
        available=False,
        club=club,
        booking__employee=coach_name
    ).filter(
        models.Q(start_time__lt=end_time, end_time__gt=start_time)
    )

    return conflicts.exists()


@login_required
def verify_and_book_appointment(request, day):
    club = get_user_club(request.user)

    # if not club:
    #     messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
    #     return redirect('index')

    # Check if logged-in user is a coach
    # try:
    coach_profile = request.user.userprofile.Coach_profile
    # except AttributeError:
    #     messages.error(request, "You must be a coach to book appointments for students.")
    #     return redirect('index')

    if request.method != 'POST':
        return redirect('coach_select_appointment_time', day=day)

    time_input = request.POST.get('time_input')
    period = request.POST.get('period')

    if not time_input or not period:
        print("Missing time or period")
        messages.error(request, "يرجى إدخال الوقت والفترة")
        return redirect('coach_select_appointment_time', day=day)

    try:
        if ':' in time_input:
            hours, minutes = time_input.split(':')
            hours = int(hours)
            minutes = int(minutes)

        if hours < 1 or hours > 12:
            messages.error(request, "صيغة الوقت غير صحيحة. يجب أن تكون الساعة من 1 إلى 12")
            return redirect('coach_select_appointment_time', day=day)

        if period == 'PM' and hours < 12:
            hours += 12
        elif period == 'AM' and hours == 12:
            hours = 0

        time_obj = datetime.strptime(f'{hours:02d}:{minutes:02d}:00', '%H:%M:%S').time()

    except ValueError as e:
        print(f"Time parsing error: {str(e)}")
        messages.error(request, "صيغة الوقت غير صحيحة. الرجاء استخدام الصيغة HH:MM")
        return redirect('coach_select_appointment_time', day=day)

    booking_form_data = request.session.get('booking_form_data', {})
    services_data = request.session.get('services_data', [])
    total_duration = request.session.get('total_duration', 0)

    if not booking_form_data or not services_data:
        messages.error(request, "بيانات الحجز غير مكتملة. الرجاء المحاولة مرة أخرى.")
        return redirect('coach_select_appointment_time')

    start_datetime = datetime.combine(datetime.today(), time_obj)
    end_datetime = start_datetime + timedelta(minutes=total_duration)
    end_time = end_datetime.time()

    # Check coach availability
    coach_conflicts = check_coach_availability(day, time_obj, end_time, coach_profile.id, club)
    if coach_conflicts:
        messages.error(request, "لديك موعد آخر في هذا الوقت. الرجاء اختيار وقت آخر.")
        return redirect('coach_select_appointment_time', day=day)

    try:
        with transaction.atomic():
            print("Creating appointment...")
            appointment = SalonAppointment.objects.create(
                day=day,
                start_time=time_obj,
                end_time=end_time,
                available=False,
                club=club,
                is_paid=True,
            )

            # Set the coach as the employee
            employee_display = coach_profile.full_name

            booking = SalonBooking.objects.create(
                appointment=appointment,
                employee=employee_display,
                created_at=datetime.now()
            )

            service_names = []
            for service_data in services_data:
                service_id = service_data.get('service_id')

                if service_id:
                    service = ServicesModel.objects.get(id=service_id)
                    service_names.append(service.title)

                    BookingService.objects.create(
                        booking=booking,
                        service=service,
                        coach_id=coach_profile.id,
                        coach_name=coach_profile.full_name
                    )



            if 'booking_form_data' in request.session:
                del request.session['booking_form_data']
            if 'services_data' in request.session:
                del request.session['services_data']
            if 'total_duration' in request.session:
                del request.session['total_duration']

            print("Redirecting to coach dashboard")
            return redirect('coach_salon_appointments')  # Or appropriate coach view

    except Exception as e:
        print(f"ERROR during booking: {str(e)}")
        import traceback
        print(traceback.format_exc())
        messages.error(request, f"حدث خطأ أثناء الحجز: {str(e)}")
        return redirect('coach_select_appointment_time', day=day)


@login_required
def book_appointment(request, day, time_slot):
    club = get_user_club(request.user)

    if not club:
        messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
        return redirect('coach_select_appointment_day')

    booking_form_data = request.session.get('booking_form_data', {})
    service_ids = request.session.get('service_ids', [])
    total_duration = request.session.get('total_duration', 0)

    if not booking_form_data or not service_ids:
        messages.error(request, "بيانات الحجز غير مكتملة. الرجاء المحاولة مرة أخرى.")
        return redirect('coach_select_appointment_day')

    try:
        time_parts = time_slot.split()
        time_str = time_parts[0]
        period = time_parts[1]

        hours, minutes = time_str.split(':')
        hours = int(hours)
        minutes = int(minutes)

        if period == 'PM' and hours < 12:
            hours += 12
        elif period == 'AM' and hours == 12:
            hours = 0

        time_obj = datetime.strptime(f'{hours:02d}:{minutes:02d}:00', '%H:%M:%S').time()
    except (ValueError, IndexError):
        messages.error(request, "صيغة الوقت غير صحيحة")
        return redirect('coach_select_appointment_time', day=day)

    start_datetime = datetime.datetime.combine(datetime.datetime.today(), time_obj)
    end_datetime = start_datetime + timedelta(minutes=total_duration)
    end_time = end_datetime.time()

    conflicts = SalonAppointment.objects.filter(
        day=day,
        available=False,
        club=club
    ).filter(
        models.Q(start_time__lt=end_time, end_time__gt=time_obj)
    )

    if conflicts.exists():
        messages.error(request, "هناك تعارض في المواعيد. الرجاء اختيار وقت آخر")
        return redirect('coach_select_appointment_time', day=day)

    try:
        with transaction.atomic():
            # Create the appointment
            appointment = SalonAppointment.objects.create(
                day=day,
                start_time=time_obj,
                end_time=end_time,
                available=False,
                club=club
            )

            employee_id = booking_form_data.get('employee_id')

            employee = booking_form_data.get('employee_name', '')

            if not employee:
                from accounts.models import CoachProfile
                try:
                    coach = CoachProfile.objects.get(id=employee_id)
                    employee = coach.full_name
                except:
                    employee = "غير محدد"

            # Create the booking
            booking = SalonBooking.objects.create(
                appointment=appointment,
                employee=employee,
                created_at=datetime.datetime.now()
            )

            # Associate services with booking and add to cart
            for service_id in service_ids:
                service = ServicesModel.objects.get(id=service_id)
                BookingService.objects.create(
                    booking=booking,
                    service=service
                )
            # Clear session data
            if 'booking_form_data' in request.session:
                del request.session['booking_form_data']
            if 'service_ids' in request.session:
                del request.session['service_ids']
            if 'total_duration' in request.session:
                del request.session['total_duration']

    except Exception as e:
        messages.error(request, f"حدث خطأ أثناء الحجز: {str(e)}")
        return redirect('coach_select_appointment_day')

@login_required
def appointment_details(request, appointment_id):
    club = get_user_club(request.user)

    if not club:
        messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
        return redirect('index')

    appointment = get_object_or_404(SalonAppointment, id=appointment_id)
    if appointment.club != club:
        messages.error(request, "ليس لديك صلاحية لعرض هذا الموعد.")
        return redirect('receptionist_salon_appointments')

    try:
        booking = appointment.booking
        # Explicitly fetch booking services
        booking_services = BookingService.objects.filter(booking=booking).select_related('service')

        if not booking_services.exists():
            messages.warning(request, "لا توجد خدمات مرتبطة بهذا الحجز")

        # For debugging
        print(f"Found {booking_services.count()} services for booking {booking.id}")

        context = {
            'appointment': appointment,
            'booking': booking,
            'employee': booking.employee,
            'booking_services': booking_services,  # Change the variable name to be more explicit
            'total_price': sum(bs.service.price for bs in booking_services),
            'total_duration': sum(bs.service.duration for bs in booking_services),
            'club':club
        }
    except Exception as e:
        messages.error(request, f"لم يتم العثور على معلومات الحجز: {str(e)}")
        return redirect('coach_salon_appointments')
    context['LANGUAGE_CODE'] = translation.get_language()
    return render(request, 'coach_dashboard/appointment_details.html', context)

@login_required
def cancel_appointment(request, appointment_id):
    club = get_user_club(request.user)

    # if not club:
    #     messages.error(request, "لم يتم تحديد نادٍ لهذا المستخدم.")
    #     return redirect('index')

    appointment = get_object_or_404(SalonAppointment, id=appointment_id)
    if appointment.club != club:
        messages.error(request, "ليس لديك صلاحية لإلغاء هذا الموعد.")
        return redirect('coach_salon_appointments')

    try:
        booking = appointment.booking
        BookingService.objects.filter(booking=booking).delete()
        booking.delete()
        appointment.delete()

        messages.success(request, "تم إلغاء الحجز بنجاح")
    except:
        messages.error(request, "لم يتم العثور على حجز لهذا الموعد")

    return redirect('coach_salon_appointments')

@login_required
def view_coach_profile(request):
    """View the coach's own profile"""
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        coach = user_profile.Coach_profile

        if not coach:
            messages.error(request, "لا يوجد ملف شخصي للمدرب")
            return redirect('dashboard')  # Redirect to a suitable page

        context = {
            'coach': coach,
            'userprofile': user_profile
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'accounts/profiles/Coach/ViewCoachProfile.html', context)
    except UserProfile.DoesNotExist:
        messages.error(request, "لا يوجد ملف شخصي")
        return redirect('dashboard')  # Redirect to a suitable page

@login_required
def edit_coach_profile(request):
    """Edit the coach's profile"""
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        coach = user_profile.Coach_profile

        if not coach:
            messages.error(request, "لا يوجد ملف شخصي للمدرب")
            return redirect('dashboard')  # Redirect to a suitable page

        if request.method == 'POST':
            form = CoachProfileForm(request.POST, instance=coach)
            if form.is_valid():
                # Save the form data
                coach_profile = form.save(commit=False)

                # Handle profile image upload
                if 'profile_image_base64' in request.FILES:
                    image_file = request.FILES['profile_image_base64']
                    encoded_image = base64.b64encode(image_file.read()).decode('utf-8')

                    # Save to both coach profile and user profile
                    coach_profile.profile_image_base64 = f"data:image/{image_file.content_type.split('/')[-1]};base64,{encoded_image}"
                    user_profile.profile_image_base64 = coach_profile.profile_image_base64
                    user_profile.save()

                coach_profile.save()
                messages.success(request, "تم تحديث الملف الشخصي بنجاح")
                return redirect('view_coach_profile')
        else:
            form = CoachProfileForm(instance=coach)

        context = {
            'form': form,
            'coach': coach
        }
        context['LANGUAGE_CODE'] = translation.get_language()
        return render(request, 'accounts/settings/Coach/EditCoachProfile.html', context)
    except UserProfile.DoesNotExist:
        messages.error(request, "لا يوجد ملف شخصي")
        return redirect('dashboard')  # Redirect to a suitable page