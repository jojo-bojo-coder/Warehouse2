from django.urls import path
from . import views
from django.utils import translation
from django.shortcuts import redirect

def set_language_redirect(request, language):
    translation.activate(language)
    response = redirect(request.GET.get('next', '/'))
    response.set_cookie('django_language', language)
    return response

urlpatterns = [

    path('', views.index, name="coachIndex"),
    path('set-language/<str:language>/', set_language_redirect, name='set_language_redirect'),
    path('viewCoachAppointments', views.viewCoachAppointments, name="viewCoachAppointments"),
    path('addCoachAppointments', views.addCoachAppointments, name="addCoachAppointments"),
    path('editCoachAppointments/<int:id>', views.editCoachAppointments, name="editCoachAppointments"),
    path('deleteCoachAppointments/<int:id>', views.deleteCoachAppointments, name="deleteCoachAppointments"),

    # path('addStudentAppointmentPresence', views.addStudentAppointmentPresence, name="addStudentAppointmentPresence"),
    # path('viewStudentAppointmentPresences', views.viewStudentAppointmentPresences, name="viewStudentAppointmentPresences"),
    # path('editStudentAppointmentPresence/<int:id>', views.editStudentAppointmentPresence, name="editStudentAppointmentPresence"),
    # path('deleteStudentAppointmentPresence/<int:id>', views.deleteStudentAppointmentPresence, name="deleteStudentAppointmentPresence"),

    path('getServiceStudents/<int:service_id>', views.getServiceStudents, name="getServiceStudents"),
    path('salon-appointments/', views.salon_appointments, name='coach_salon_appointments'),
    path('salon/appointment/<int:appointment_id>/', views.appointment_details, name='coach_appointment_details'),
    path('coach/profile/', views.view_coach_profile, name='view_coach_profile'),
    path('coach/profile/edit/', views.edit_coach_profile, name='edit_coach_profile'),
    path('slot_appointments/<str:day>/<str:time>/', views.slot_appointments, name='coach_slot_appointments'),
    path('club/select-day/', views.select_appointment_day, name='coach_select_appointment_day'),
    path('club/book/<str:day>/', views.book_appointment_details, name='coach_book_appointment_details'),
    path('select-appointment-time/<str:day>/', views.select_appointment_time, name='coach_select_appointment_time'),
    path('club/service-info/<int:service_id>/', views.get_service_info, name='get_service_info'),
    path('verify-and-book-appointment/<str:day>/', views.verify_and_book_appointment, name='coach_verify_and_book_appointment'),
    path('salon/book/<str:day>/<str:time_slot>/', views.book_appointment, name='coach_book_appointment'),
    path('salon/cancel/<int:appointment_id>/', views.cancel_appointment, name='coach_cancel_appointment'),
]
