from django.urls import path
from . import views
from django.utils import translation
from django.shortcuts import redirect
from django.conf import settings

def set_language_redirect(request, language):
    translation.activate(language)
    response = redirect(request.GET.get('next', '/'))
    response.set_cookie('django_language', language)
    return response

urlpatterns = [
    path('signin', views.signin, name='signin'),
    path('signup', views.signup, name='signup'),
    path('signout', views.signout, name='signout'),
    path('verify-otp', views.verify_otp, name='verify_otp'),  # Add this line
    path('set-language/<str:language>/', set_language_redirect, name='set_language_redirect'),
]
